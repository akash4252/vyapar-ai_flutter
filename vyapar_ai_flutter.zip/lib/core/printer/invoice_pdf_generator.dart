import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../utils/number_to_words.dart';

class InvoicePdfGenerator {
  static Future<Uint8List> generateGstInvoicePdf({
    required String businessName,
    required String address,
    required String? mobile,
    required String? gstin,
    required String invoiceNumber,
    required String date,
    required String customerName,
    required String? customerPhone,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    required double discount,
    required double cgst,
    required double sgst,
    required double igst,
    required double grandTotal,
    required String paymentMode,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(24),
        build: (pw.Context context) {
          return pw.Column(
            crossContent: pw.CrossAxisAlignment.start,
            children: [
              // Header
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        businessName,
                        style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold, color: PdfColors.green900),
                      ),
                      if (address.isNotEmpty) pw.Text(address, style: const pw.TextStyle(fontSize: 10)),
                      if (mobile != null) pw.Text("Phone: $mobile", style: const pw.TextStyle(fontSize: 10)),
                      if (gstin != null) pw.Text("GSTIN: $gstin", style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                    ],
                  ),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Container(
                        padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: pw.BoxDecoration(
                          color: PdfColors.green100,
                          borderRadius: pw.BorderRadius.circular(6),
                        ),
                        child: pw.Text("TAX INVOICE", style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.green900)),
                      ),
                      pw.SizedBox(height: 6),
                      pw.Text("Invoice No: $invoiceNumber", style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
                      pw.Text("Date: $date", style: const pw.TextStyle(fontSize: 10)),
                    ],
                  ),
                ],
              ),
              pw.Divider(thickness: 1, color: PdfColors.grey400),
              pw.SizedBox(height: 8),

              // Billed To
              pw.Container(
                padding: const pw.EdgeInsets.all(10),
                decoration: pw.BoxDecoration(
                  color: PdfColors.grey100,
                  borderRadius: pw.BorderRadius.circular(6),
                ),
                child: pw.Row(
                  children: [
                    pw.Text("Billed To: ", style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
                    pw.Text(customerName, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11, color: PdfColors.blue900)),
                    if (customerPhone != null) pw.Text(" | Phone: $customerPhone", style: const pw.TextStyle(fontSize: 11)),
                  ],
                ),
              ),
              pw.SizedBox(height: 12),

              // Table
              pw.Table(
                border: pw.TableBorder.all(color: PdfColors.grey300),
                columnWidths: {
                  0: const pw.FlexColumnWidth(1),
                  1: const pw.FlexColumnWidth(5),
                  2: const pw.FlexColumnWidth(2),
                  3: const pw.FlexColumnWidth(2),
                  4: const pw.FlexColumnWidth(2),
                  5: const pw.FlexColumnWidth(2.5),
                },
                children: [
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(color: PdfColors.green50),
                    children: [
                      _th("#"),
                      _th("Item Description"),
                      _th("Qty"),
                      _th("Unit Price"),
                      _th("GST %"),
                      _th("Total (Rs.)"),
                    ],
                  ),
                  ...items.asMap().entries.map((entry) {
                    final idx = entry.key + 1;
                    final itm = entry.value;
                    return pw.TableRow(
                      children: [
                        _td("$idx", align: pw.TextAlign.center),
                        _td(itm['name'] as String),
                        _td("${itm['qty']} ${itm['unit'] ?? 'pcs'}", align: pw.TextAlign.center),
                        _td((itm['price'] as num).toStringAsFixed(2), align: pw.TextAlign.right),
                        _td("${itm['gstRate'] ?? 0}%", align: pw.TextAlign.center),
                        _td((itm['total'] as num).toStringAsFixed(2), align: pw.TextAlign.right),
                      ],
                    );
                  }),
                ],
              ),
              pw.SizedBox(height: 12),

              // Totals
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text("Amount in Words:", style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                        pw.Text(IndianNumberToWords.convert(grandTotal), style: const pw.TextStyle(fontSize: 10)),
                        pw.SizedBox(height: 10),
                        pw.Text("Payment Mode: $paymentMode", style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: PdfColors.green900)),
                      ],
                    ),
                  ),
                  pw.SizedBox(width: 20),
                  pw.Container(
                    width: 200,
                    child: pw.Column(
                      children: [
                        _totalRow("Subtotal:", "Rs. ${subtotal.toStringAsFixed(2)}"),
                        if (discount > 0) _totalRow("Discount:", "-Rs. ${discount.toStringAsFixed(2)}", color: PdfColors.red900),
                        if (cgst > 0) _totalRow("CGST:", "Rs. ${cgst.toStringAsFixed(2)}"),
                        if (sgst > 0) _totalRow("SGST:", "Rs. ${sgst.toStringAsFixed(2)}"),
                        if (igst > 0) _totalRow("IGST:", "Rs. ${igst.toStringAsFixed(2)}"),
                        pw.Divider(thickness: 1, color: PdfColors.grey500),
                        _totalRow("Grand Total:", "Rs. ${grandTotal.toStringAsFixed(2)}", isBold: true, fontSize: 13, color: PdfColors.green900),
                      ],
                    ),
                  ),
                ],
              ),
              pw.Spacer(),

              // Footer
              pw.Divider(thickness: 0.5, color: PdfColors.grey300),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text("Terms: Goods once sold will not be returned after 7 days.", style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
                  pw.Text("Generated by VYAPAR AI", style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.green900)),
                ],
              ),
            ],
          );
        },
      ),
    );

    return pdf.save();
  }

  static pw.Widget _th(String text) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(text, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9)),
    );
  }

  static pw.Widget _td(String text, {pw.TextAlign align = pw.TextAlign.left}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(text, textAlign: align, style: const pw.TextStyle(fontSize: 9)),
    );
  }

  static pw.Widget _totalRow(String label, String value, {bool isBold = false, double fontSize = 10, PdfColor? color}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label, style: pw.TextStyle(fontSize: fontSize, fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          pw.Text(value, style: pw.TextStyle(fontSize: fontSize, fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color)),
        ],
      ),
    );
  }
}
