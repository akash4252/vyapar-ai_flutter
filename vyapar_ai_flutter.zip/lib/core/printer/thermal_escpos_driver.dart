import 'dart:convert';
import 'dart:typed_data';

enum ThermalPaperWidth { mm58, mm80 }

class ThermalEscPosDriver {
  static const int esc = 0x1B;
  static const int gs = 0x1D;

  static Uint8List formatThermalReceipt({
    required String businessName,
    required String address,
    required String? mobile,
    required String? gstin,
    required String invoiceNumber,
    required String date,
    required String customerName,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    required double discount,
    required double gst,
    required double grandTotal,
    required String paymentMethod,
    ThermalPaperWidth paperWidth = ThermalPaperWidth.mm58,
  }) {
    final int maxCols = paperWidth == ThermalPaperWidth.mm58 ? 32 : 48;
    final BytesBuilder bytes = BytesBuilder();

    // Initialize Printer
    bytes.add([esc, 0x40]);

    // Center Align
    bytes.add([esc, 0x61, 0x01]);

    // Double height/width for Store Name
    bytes.add([esc, 0x21, 0x30]);
    bytes.add(utf8.encode("$businessName\n"));

    // Normal Text
    bytes.add([esc, 0x21, 0x00]);
    if (address.isNotEmpty) bytes.add(utf8.encode("$address\n"));
    if (mobile != null) bytes.add(utf8.encode("Mob: $mobile\n"));
    if (gstin != null) bytes.add(utf8.encode("GSTIN: $gstin\n"));

    // Separator line
    bytes.add(utf8.encode("${'-' * maxCols}\n"));

    // Left Align
    bytes.add([esc, 0x61, 0x00]);
    bytes.add(utf8.encode("Bill No: $invoiceNumber\n"));
    bytes.add(utf8.encode("Date: $date\n"));
    bytes.add(utf8.encode("Customer: $customerName\n"));
    bytes.add(utf8.encode("${'-' * maxCols}\n"));

    // Header
    if (paperWidth == ThermalPaperWidth.mm58) {
      bytes.add(utf8.encode("Item           Qty   Price  Total\n"));
    } else {
      bytes.add(utf8.encode("Item Name                   Qty   Rate    Amount\n"));
    }
    bytes.add(utf8.encode("${'-' * maxCols}\n"));

    // Items
    for (final item in items) {
      final name = item['name'] as String;
      final qty = (item['qty'] as num).toDouble();
      final price = (item['price'] as num).toDouble();
      final total = (item['total'] as num).toDouble();

      final line = "${name.padRight(14).substring(0, 14)} ${qty.toStringAsFixed(0).padLeft(3)} ${price.toStringAsFixed(0).padLeft(6)} ${total.toStringAsFixed(0).padLeft(6)}\n";
      bytes.add(utf8.encode(line));
    }

    bytes.add(utf8.encode("${'-' * maxCols}\n"));

    // Totals Right Aligned
    bytes.add([esc, 0x61, 0x02]);
    bytes.add(utf8.encode("Subtotal: Rs.${subtotal.toStringAsFixed(2)}\n"));
    if (discount > 0) bytes.add(utf8.encode("Discount: -Rs.${discount.toStringAsFixed(2)}\n"));
    if (gst > 0) bytes.add(utf8.encode("GST Tax: Rs.${gst.toStringAsFixed(2)}\n"));

    // Bold Grand Total
    bytes.add([esc, 0x45, 0x01]);
    bytes.add(utf8.encode("GRAND TOTAL: Rs.${grandTotal.toStringAsFixed(2)}\n"));
    bytes.add([esc, 0x45, 0x00]);

    bytes.add(utf8.encode("Payment: $paymentMethod\n"));
    bytes.add(utf8.encode("${'-' * maxCols}\n"));

    // Center Align Footer
    bytes.add([esc, 0x61, 0x01]);
    bytes.add(utf8.encode("Thank you! Visit Again.\n"));
    bytes.add(utf8.encode("Powered by Vyapar AI\n\n\n\n"));

    // Cut Paper
    bytes.add([gs, 0x56, 0x41, 0x00]);

    return bytes.toBytes();
  }
}
