class HindiMarathiNormalizer {
  static const Map<String, String> _devanagariDigits = {
    '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
    '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
  };

  static const Map<String, double> _wordToNumber = {
    // English
    "one": 1.0, "two": 2.0, "three": 3.0, "four": 4.0, "five": 5.0,
    "six": 6.0, "seven": 7.0, "eight": 8.0, "nine": 9.0, "ten": 10.0,
    "half": 0.5, "quarter": 0.25,

    // Hindi
    "एक": 1.0, "दो": 2.0, "तीन": 3.0, "चार": 4.0, "पांच": 5.0, "पाँच": 5.0,
    "छह": 6.0, "सात": 7.0, "आठ": 8.0, "नौ": 9.0, "दस": 10.0,
    "आधा": 0.5, "पाव": 0.25, "डेढ़": 1.5, "ढाई": 2.5,

    // Marathi
    "दोन": 2.0, "पाच": 5.0, "सहा": 6.0, "नऊ": 9.0, "दहा": 10.0,
    "अर्धा": 0.5, "सव्वा": 1.25, "दीड": 1.5
  };

  static const Map<String, String> _unitMap = {
    "kg": "kg", "kilo": "kg", "kilos": "kg", "किलो": "kg", "किग्रा": "kg",
    "gm": "gm", "gram": "gm", "grams": "gm", "ग्राम": "gm",
    "ltr": "ltr", "liter": "ltr", "litre": "ltr", "लिटर": "ltr", "लीटर": "ltr",
    "ml": "ml", "मिली": "ml",
    "pkt": "pkt", "packet": "pkt", "packets": "pkt", "पाकीट": "pkt", "पैकेट": "pkt",
    "pc": "pcs", "pcs": "pcs", "piece": "pcs", "pieces": "pcs", "नग": "pcs",
    "box": "box", "boxes": "box", "खोके": "box", "डब्बा": "box", "डब्बे": "box",
    "dozen": "dozen", "डझन": "dozen", "दर्जन": "dozen"
  };

  static String normalizeDevanagariDigits(String input) {
    String output = input;
    _devanagariDigits.forEach((key, value) {
      output = output.replaceAll(key, value);
    });
    return output;
  }

  static double? parseWordOrNumber(String word) {
    final lower = word.toLowerCase().trim();
    final directDouble = double.tryParse(lower);
    if (directDouble != null) return directDouble;
    return _wordToNumber[lower];
  }

  static String? normalizeUnit(String word) {
    final lower = word.toLowerCase().trim();
    return _unitMap[lower];
  }
}
