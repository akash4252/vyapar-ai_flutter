import 'normalizer.dart';

class VoiceParsedItem {
  final String productName;
  final double quantity;
  final String unit;
  final double? price;

  VoiceParsedItem({
    required this.productName,
    required this.quantity,
    this.unit = "pcs",
    this.price,
  });
}

enum BusinessQueryType {
  todaySales,
  todayProfit,
  lowStock,
  topProducts,
  monthlySales,
  purchaseSuggestions,
}

abstract class VoiceCommandResult {}

class BillingVoiceCommand extends VoiceCommandResult {
  final List<VoiceParsedItem> items;
  final String? customerName;
  final bool isCredit;

  BillingVoiceCommand({
    required this.items,
    this.customerName,
    this.isCredit = false,
  });
}

class KhataCreditVoiceCommand extends VoiceCommandResult {
  final String customerName;
  final double amount;
  final String? note;

  KhataCreditVoiceCommand({
    required this.customerName,
    required this.amount,
    this.note,
  });
}

class KhataPaymentVoiceCommand extends VoiceCommandResult {
  final String customerName;
  final double amount;

  KhataPaymentVoiceCommand({
    required this.customerName,
    required this.amount,
  });
}

class KhataQueryVoiceCommand extends VoiceCommandResult {
  final String customerName;
  KhataQueryVoiceCommand(this.customerName);
}

class BusinessQueryVoiceCommand extends VoiceCommandResult {
  final BusinessQueryType queryType;
  BusinessQueryVoiceCommand(this.queryType);
}

class UnknownVoiceCommand extends VoiceCommandResult {
  final String rawText;
  UnknownVoiceCommand(this.rawText);
}

class VoiceParserEngine {
  static VoiceCommandResult parse(String speechInput) {
    if (speechInput.trim().isEmpty) {
      return UnknownVoiceCommand(speechInput);
    }

    final normalized = HindiMarathiNormalizer.normalizeDevanagariDigits(speechInput.trim());
    final lower = normalized.toLowerCase();

    // 1. Business Intelligence Queries
    if (lower.contains("sales") || lower.contains("विक्री") || lower.contains("बिक्री") || lower.contains("dhandha") || lower.contains("धंदा")) {
      if (lower.contains("month") || lower.contains("महिना") || lower.contains("mahina")) {
        return BusinessQueryVoiceCommand(BusinessQueryType.monthlySales);
      }
      return BusinessQueryVoiceCommand(BusinessQueryType.todaySales);
    }
    if (lower.contains("profit") || lower.contains("नफा") || lower.contains("कमाई") || lower.contains("kamai")) {
      return BusinessQueryVoiceCommand(BusinessQueryType.todayProfit);
    }
    if (lower.contains("low stock") || lower.contains("stock") || lower.contains("कमी माल") || lower.contains("साठा")) {
      return BusinessQueryVoiceCommand(BusinessQueryType.lowStock);
    }
    if (lower.contains("top") || lower.contains("जास्त") || lower.contains("best selling")) {
      return BusinessQueryVoiceCommand(BusinessQueryType.topProducts);
    }

    // 2. Khata Voice Commands
    final creditMatch = RegExp(r'(\b[A-Za-z\u0900-\u097F]+\b)\s+(?:ko|ला|चे)\s+(\d+(?:\.\d+)?)\s*(?:rupees?|rs|रुपये|रूपये|रु)?\s*(?:udhaar|credit|उधार|baaki)', caseSensitive: false).firstMatch(lower);
    if (creditMatch != null) {
      final name = creditMatch.group(1)!;
      final amt = double.tryParse(creditMatch.group(2)!) ?? 0.0;
      return KhataCreditVoiceCommand(customerName: name, amount: amt);
    }

    final paymentMatch = RegExp(r'(\b[A-Za-z\u0900-\u097F]+\b)\s+(?:ne|ने|कडून)\s+(\d+(?:\.\d+)?)\s*(?:rupees?|rs|रुपये|रूपये|रु)?\s*(?:diye|jama|दिले|जमा)', caseSensitive: false).firstMatch(lower);
    if (paymentMatch != null) {
      final name = paymentMatch.group(1)!;
      final amt = double.tryParse(paymentMatch.group(2)!) ?? 0.0;
      return KhataPaymentVoiceCommand(customerName: name, amount: amt);
    }

    final khataQueryMatch = RegExp(r'(\b[A-Za-z\u0900-\u097F]+\b)\s+(?:ka|चे|चा)\s+(?:khata|खाते|balance|बाकी)', caseSensitive: false).firstMatch(lower);
    if (khataQueryMatch != null) {
      return KhataQueryVoiceCommand(khataQueryMatch.group(1)!);
    }

    // 3. Multi-Item Billing Voice Command
    final clauses = lower.split(RegExp(r'\s+(?:and|ani|aur|आणि|और|,)\s+'));
    final List<VoiceParsedItem> items = [];

    for (final clause in clauses) {
      final item = _parseSingleClause(clause.trim());
      if (item != null) {
        items.add(item);
      }
    }

    if (items.isNotEmpty) {
      return BillingVoiceCommand(items: items);
    }

    return UnknownVoiceCommand(speechInput);
  }

  static VoiceParsedItem? _parseSingleClause(String clause) {
    if (clause.isEmpty) return null;

    // Pattern A: "Sugar 2kg 80 rupees" or "Sugar 2 kg 80 rs"
    final patternWithPrice = RegExp(r'^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z\u0900-\u097F]+)?\s+(?:at|rate|@|for|किंमत|भाव)?\s*(\d+(?:\.\d+)?)\s*(?:rupees?|rs|रुपये|रूपये|रु)?$');
    final matchA = patternWithPrice.firstMatch(clause);
    if (matchA != null) {
      final name = matchA.group(1)!.trim();
      final qty = double.tryParse(matchA.group(2)!) ?? 1.0;
      final rawUnit = matchA.group(3);
      final price = double.tryParse(matchA.group(4)!);
      final unit = rawUnit != null ? (HindiMarathiNormalizer.normalizeUnit(rawUnit) ?? "pcs") : "pcs";
      return VoiceParsedItem(productName: name, quantity: qty, unit: unit, price: price);
    }

    // Pattern B: "Maggi 2", "Milk 3 packets", "मैगी दो", "मॅगी दोन"
    final tokens = clause.split(RegExp(r'\s+'));
    if (tokens.length >= 2) {
      final lastToken = tokens.last;
      final parsedNum = HindiMarathiNormalizer.parseWordOrNumber(lastToken);

      if (parsedNum != null) {
        final name = tokens.sublist(0, tokens.length - 1).join(" ");
        return VoiceParsedItem(productName: name, quantity: parsedNum);
      }

      // Check if second-to-last is number and last is unit
      if (tokens.length >= 3) {
        final secLastToken = tokens[tokens.length - 2];
        final unitToken = tokens.last;
        final numVal = HindiMarathiNormalizer.parseWordOrNumber(secLastToken);
        final unitVal = HindiMarathiNormalizer.normalizeUnit(unitToken);

        if (numVal != null && unitVal != null) {
          final name = tokens.sublist(0, tokens.length - 2).join(" ");
          return VoiceParsedItem(productName: name, quantity: numVal, unit: unitVal);
        }
      }
    }

    // Fallback: entire clause as 1 piece
    return VoiceParsedItem(productName: clause, quantity: 1.0);
  }
}
