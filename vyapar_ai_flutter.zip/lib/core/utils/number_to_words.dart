class IndianNumberToWords {
  static const List<String> _units = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
  ];

  static const List<String> _tens = [
    "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
  ];

  static String convert(double amount) {
    if (amount == 0) return "Rupees Zero Only";

    final int rupees = amount.toInt();
    final int paise = ((amount - rupees) * 100).round();

    final StringBuffer buffer = StringBuffer();
    if (rupees > 0) {
      buffer.write("Rupees ${_convertRupees(rupees)}");
    }

    if (paise > 0) {
      if (rupees > 0) buffer.write(" and ");
      buffer.write("${_convertRupees(paise)} Paise");
    }

    buffer.write(" Only");
    return buffer.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static String _convertRupees(int n) {
    if (n < 0) return "Minus ${_convertRupees(-n)}";
    if (n == 0) return "";

    if (n < 20) return _units[n];
    if (n < 100) return "${_tens[n ~/ 10]} ${_units[n % 10]}";
    if (n < 1000) return "${_units[n ~/ 100]} Hundred ${_convertRupees(n % 100)}";
    if (n < 100000) return "${_convertRupees(n ~/ 1000)} Thousand ${_convertRupees(n % 1000)}";
    if (n < 10000000) return "${_convertRupees(n ~/ 100000)} Lakh ${_convertRupees(n % 100000)}";
    return "${_convertRupees(n ~/ 10000000)} Crore ${_convertRupees(n % 10000000)}";
  }
}
