import 'package:intl/intl.dart';

class AppDateUtils {
  static String formatDate(DateTime date) {
    return DateFormat('dd/MM/yyyy').format(date);
  }

  static String formatDateTime(DateTime date) {
    return DateFormat('dd/MM/yyyy, hh:mm a').format(date);
  }

  static String formatTime(DateTime date) {
    return DateFormat('hh:mm a').format(date);
  }

  static DateTime getStartOfDay([DateTime? date]) {
    final d = date ?? DateTime.now();
    return DateTime(d.year, d.month, d.day, 0, 0, 0);
  }

  static DateTime getEndOfDay([DateTime? date]) {
    final d = date ?? DateTime.now();
    return DateTime(d.year, d.month, d.day, 23, 59, 59, 999);
  }

  static DateTime getStartOfWeek([DateTime? date]) {
    final d = date ?? DateTime.now();
    final daysToSubtract = d.weekday - 1;
    final monday = d.subtract(Duration(days: daysToSubtract));
    return DateTime(monday.year, monday.month, monday.day, 0, 0, 0);
  }

  static DateTime getStartOfMonth([DateTime? date]) {
    final d = date ?? DateTime.now();
    return DateTime(d.year, d.month, 1, 0, 0, 0);
  }
}
