class UpiQrGenerator {
  static String buildUpiUri({
    required String upiId,
    required String payeeName,
    required double amount,
    required String transactionNote,
    String? transactionRef,
  }) {
    final cleanUpi = upiId.trim();
    final cleanName = Uri.encodeComponent(payeeName.trim());
    final cleanNote = Uri.encodeComponent(transactionNote.trim());
    final formattedAmount = amount.toStringAsFixed(2);
    final trParam = transactionRef != null ? "&tr=${Uri.encodeComponent(transactionRef)}" : "";

    return "upi://pay?pa=$cleanUpi&pn=$cleanName&am=$formattedAmount&cu=INR&tn=$cleanNote$trParam";
  }
}
