import 'package:flutter/material.dart';

class AppColors {
  // Brand Green (Vyapar AI Signature)
  static const Color primaryGreen = Color(0xFF1B5E20);
  static const Color primaryLight = Color(0xFF4C8C4A);
  static const Color primaryDark = Color(0xFF003300);
  static const Color primaryContainer = Color(0xFFA7F3D0);
  static const Color onPrimaryContainer = Color(0xFF064E3B);

  // Secondary Amber (Kirana accents)
  static const Color secondaryAmber = Color(0xFFF59E0B);
  static const Color secondaryDark = Color(0xFFD97706);
  static const Color secondaryContainer = Color(0xFFFEF3C7);

  // Tertiary Blue (Invoicing & GST)
  static const Color tertiaryBlue = Color(0xFF1E40AF);
  static const Color tertiaryContainer = Color(0xFFDBEAFE);

  // Status Colors
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);

  // Background & Surface
  static const Color backgroundLight = Color(0xFFF8FAFC);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color surfaceVariantLight = Color(0xFFF1F5F9);

  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color border = Color(0xFFE2E8F0);
}
