import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'data/models/customer.dart';
import 'data/models/product.dart';
import 'presentation/navigation/app_routes.dart';
import 'presentation/navigation/main_navigation_scaffold.dart';
import 'presentation/screens/splash_screen.dart';
import 'presentation/screens/fast_billing_screen.dart';
import 'presentation/screens/barcode_scanner_screen.dart';
import 'presentation/screens/payment_checkout_screen.dart';
import 'presentation/screens/invoice_success_screen.dart';
import 'presentation/screens/bill_history_screen.dart';
import 'presentation/screens/product_list_screen.dart';
import 'presentation/screens/add_edit_product_screen.dart';
import 'presentation/screens/inventory_dashboard_screen.dart';
import 'presentation/screens/stock_adjustment_screen.dart';
import 'presentation/screens/low_stock_screen.dart';
import 'presentation/screens/digital_khata_screen.dart';
import 'presentation/screens/customer_profile_screen.dart';
import 'presentation/screens/add_khata_entry_screen.dart';
import 'presentation/screens/customer_loyalty_screen.dart';
import 'presentation/screens/supplier_list_screen.dart';
import 'presentation/screens/new_purchase_screen.dart';
import 'presentation/screens/smart_po_screen.dart';
import 'presentation/screens/ai_bill_scanner_screen.dart';
import 'presentation/screens/reports_hub_screen.dart';
import 'presentation/screens/sales_report_screen.dart';
import 'presentation/screens/profit_report_screen.dart';
import 'presentation/screens/gst_report_screen.dart';
import 'presentation/screens/expense_manager_screen.dart';
import 'presentation/screens/ai_assistant_screen.dart';
import 'presentation/screens/settings_hub_screen.dart';
import 'presentation/screens/printer_settings_screen.dart';
import 'presentation/screens/backup_restore_screen.dart';
import 'presentation/screens/language_settings_screen.dart';
import 'providers/billing_provider.dart';
import 'providers/product_provider.dart';
import 'providers/khata_provider.dart';
import 'providers/report_provider.dart';
import 'providers/settings_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VyaparAiApp());
}

class VyaparAiApp extends StatelessWidget {
  const VyaparAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
        ChangeNotifierProvider(create: (_) => KhataProvider()),
        ChangeNotifierProvider(create: (_) => ReportProvider()),
        ChangeNotifierProvider(create: (_) => BillingProvider()),
      ],
      child: MaterialApp(
        title: 'VYAPAR AI',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        initialRoute: AppRoutes.splash,
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case AppRoutes.splash:
              return MaterialPageRoute(builder: (_) => const SplashScreen());
            case AppRoutes.dashboard:
              return MaterialPageRoute(builder: (_) => const MainNavigationScaffold());
            case AppRoutes.fastBilling:
              return MaterialPageRoute(builder: (_) => const FastBillingScreen());
            case AppRoutes.barcodeScanner:
              return MaterialPageRoute(builder: (_) => const BarcodeScannerScreen());
            case AppRoutes.paymentCheckout:
              return MaterialPageRoute(builder: (_) => const PaymentCheckoutScreen());
            case AppRoutes.invoiceSuccess:
              final invNum = settings.arguments as String? ?? "VX-2026-000001";
              return MaterialPageRoute(builder: (_) => InvoiceSuccessScreen(invoiceNumber: invNum));
            case AppRoutes.billHistory:
              return MaterialPageRoute(builder: (_) => const BillHistoryScreen());
            case AppRoutes.productList:
              return MaterialPageRoute(builder: (_) => const ProductListScreen());
            case AppRoutes.addEditProduct:
              return MaterialPageRoute(builder: (_) => AddEditProductScreen(argument: settings.arguments));
            case AppRoutes.inventoryDashboard:
              return MaterialPageRoute(builder: (_) => const InventoryDashboardScreen());
            case AppRoutes.stockAdjustment:
              return MaterialPageRoute(builder: (_) => const StockAdjustmentScreen());
            case AppRoutes.lowStock:
              return MaterialPageRoute(builder: (_) => const LowStockScreen());
            case AppRoutes.digitalKhata:
              return MaterialPageRoute(builder: (_) => const DigitalKhataScreen());
            case AppRoutes.customerProfile:
              final cust = settings.arguments as Customer;
              return MaterialPageRoute(builder: (_) => CustomerProfileScreen(customer: cust));
            case AppRoutes.addKhataEntry:
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(builder: (_) => AddKhataEntryScreen(arguments: args));
            case AppRoutes.customerLoyalty:
              return MaterialPageRoute(builder: (_) => const CustomerLoyaltyScreen());
            case AppRoutes.suppliers:
              return MaterialPageRoute(builder: (_) => const SupplierListScreen());
            case AppRoutes.newPurchase:
              return MaterialPageRoute(builder: (_) => const NewPurchaseScreen());
            case AppRoutes.smartPo:
              return MaterialPageRoute(builder: (_) => const SmartPoScreen());
            case AppRoutes.aiBillScanner:
              return MaterialPageRoute(builder: (_) => const AiBillScannerScreen());
            case AppRoutes.reportsHub:
              return MaterialPageRoute(builder: (_) => const ReportsHubScreen());
            case AppRoutes.salesReport:
              return MaterialPageRoute(builder: (_) => const SalesReportScreen());
            case AppRoutes.profitReport:
              return MaterialPageRoute(builder: (_) => const ProfitReportScreen());
            case AppRoutes.gstReport:
              return MaterialPageRoute(builder: (_) => const GstReportScreen());
            case AppRoutes.expenseManager:
              return MaterialPageRoute(builder: (_) => const ExpenseManagerScreen());
            case AppRoutes.aiAssistant:
              return MaterialPageRoute(builder: (_) => const AiAssistantScreen());
            case AppRoutes.settingsHub:
              return MaterialPageRoute(builder: (_) => const SettingsHubScreen());
            case AppRoutes.printerSettings:
              return MaterialPageRoute(builder: (_) => const PrinterSettingsScreen());
            case AppRoutes.backupRestore:
              return MaterialPageRoute(builder: (_) => const BackupRestoreScreen());
            case AppRoutes.languageSettings:
              return MaterialPageRoute(builder: (_) => const LanguageSettingsScreen());
            default:
              return MaterialPageRoute(builder: (_) => const MainNavigationScaffold());
          }
        },
      ),
    );
  }
}
