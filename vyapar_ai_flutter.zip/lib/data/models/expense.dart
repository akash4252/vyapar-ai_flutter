class Expense {
  final int? id;
  final String category;
  final double amount;
  final String? description;
  final DateTime date;

  Expense({
    this.id,
    required this.category,
    required this.amount,
    this.description,
    DateTime? date,
  }) : date = date ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category': category,
      'amount': amount,
      'description': description,
      'date': date.millisecondsSinceEpoch,
    };
  }

  factory Expense.fromMap(Map<String, dynamic> map) {
    return Expense(
      id: map['id'] as int?,
      category: map['category'] as String,
      amount: (map['amount'] as num).toDouble(),
      description: map['description'] as String?,
      date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
    );
  }
}

class BusinessInfo {
  final int id;
  final String name;
  final String? tradeName;
  final String? gstin;
  final String? mobile;
  final String? address;
  final String? upiId;
  final String shopType;

  BusinessInfo({
    this.id = 1,
    required this.name,
    this.tradeName,
    this.gstin,
    this.mobile,
    this.address,
    this.upiId,
    this.shopType = "Kirana Store",
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'trade_name': tradeName,
      'gstin': gstin,
      'mobile': mobile,
      'address': address,
      'upi_id': upiId,
      'shop_type': shopType,
    };
  }

  factory BusinessInfo.fromMap(Map<String, dynamic> map) {
    return BusinessInfo(
      id: map['id'] as int? ?? 1,
      name: map['name'] as String,
      tradeName: map['trade_name'] as String?,
      gstin: map['gstin'] as String?,
      mobile: map['mobile'] as String?,
      address: map['address'] as String?,
      upiId: map['upi_id'] as String?,
      shopType: map['shop_type'] as String? ?? "Kirana Store",
    );
  }
}
