class Product {
  final int? id;
  final String name;
  final String? localName;
  final String? barcode;
  final String? hsnCode;
  final double purchasePrice;
  final double sellingPrice;
  final double mrp;
  final double gstRate;
  final bool isTaxInclusive;
  final double currentStock;
  final double minimumStock;
  final double maximumStock;
  final String unit;
  final String? category;
  final String? brand;
  final List<String> aliases;

  Product({
    this.id,
    required this.name,
    this.localName,
    this.barcode,
    this.hsnCode,
    required this.purchasePrice,
    required this.sellingPrice,
    double? mrp,
    this.gstRate = 0.0,
    this.isTaxInclusive = true,
    this.currentStock = 0.0,
    this.minimumStock = 5.0,
    this.maximumStock = 100.0,
    this.unit = "pcs",
    this.category,
    this.brand,
    this.aliases = const [],
  }) : mrp = mrp ?? sellingPrice;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'local_name': localName,
      'barcode': barcode,
      'hsn_code': hsnCode,
      'purchase_price': purchasePrice,
      'selling_price': sellingPrice,
      'mrp': mrp,
      'gst_rate': gstRate,
      'is_tax_inclusive': isTaxInclusive ? 1 : 0,
      'current_stock': currentStock,
      'minimum_stock': minimumStock,
      'maximum_stock': maximumStock,
      'unit': unit,
      'category': category,
      'brand': brand,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map, [List<String> aliases = const []]) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      localName: map['local_name'] as String?,
      barcode: map['barcode'] as String?,
      hsnCode: map['hsn_code'] as String?,
      purchasePrice: (map['purchase_price'] as num).toDouble(),
      sellingPrice: (map['selling_price'] as num).toDouble(),
      mrp: (map['mrp'] as num?)?.toDouble() ?? (map['selling_price'] as num).toDouble(),
      gstRate: (map['gst_rate'] as num?)?.toDouble() ?? 0.0,
      isTaxInclusive: (map['is_tax_inclusive'] as int?) == 1,
      currentStock: (map['current_stock'] as num?)?.toDouble() ?? 0.0,
      minimumStock: (map['minimum_stock'] as num?)?.toDouble() ?? 5.0,
      maximumStock: (map['maximum_stock'] as num?)?.toDouble() ?? 100.0,
      unit: map['unit'] as String? ?? "pcs",
      category: map['category'] as String?,
      brand: map['brand'] as String?,
      aliases: aliases,
    );
  }

  Product copyWith({
    int? id,
    String? name,
    String? localName,
    String? barcode,
    String? hsnCode,
    double? purchasePrice,
    double? sellingPrice,
    double? mrp,
    double? gstRate,
    bool? isTaxInclusive,
    double? currentStock,
    double? minimumStock,
    double? maximumStock,
    String? unit,
    String? category,
    String? brand,
    List<String>? aliases,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      localName: localName ?? this.localName,
      barcode: barcode ?? this.barcode,
      hsnCode: hsnCode ?? this.hsnCode,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      sellingPrice: sellingPrice ?? this.sellingPrice,
      mrp: mrp ?? this.mrp,
      gstRate: gstRate ?? this.gstRate,
      isTaxInclusive: isTaxInclusive ?? this.isTaxInclusive,
      currentStock: currentStock ?? this.currentStock,
      minimumStock: minimumStock ?? this.minimumStock,
      maximumStock: maximumStock ?? this.maximumStock,
      unit: unit ?? this.unit,
      category: category ?? this.category,
      brand: brand ?? this.brand,
      aliases: aliases ?? this.aliases,
    );
  }
}
