class Invoice {
  final int? id;
  final String invoiceNumber;
  final int? customerId;
  final String customerName;
  final String? customerMobile;
  final double subtotal;
  final double discountAmount;
  final double cgst;
  final double sgst;
  final double igst;
  final double totalGst;
  final double grandTotal;
  final double roundOff;
  final String paymentMode; // CASH, UPI, CREDIT, MIXED
  final String status; // COMPLETED, CANCELLED, RETURNED
  final DateTime createdAt;

  Invoice({
    this.id,
    required this.invoiceNumber,
    this.customerId,
    this.customerName = "Walk-in Customer",
    this.customerMobile,
    required this.subtotal,
    this.discountAmount = 0.0,
    this.cgst = 0.0,
    this.sgst = 0.0,
    this.igst = 0.0,
    this.totalGst = 0.0,
    required this.grandTotal,
    this.roundOff = 0.0,
    this.paymentMode = "CASH",
    this.status = "COMPLETED",
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'invoice_number': invoiceNumber,
      'customer_id': customerId,
      'customer_name': customerName,
      'customer_mobile': customerMobile,
      'subtotal': subtotal,
      'discount_amount': discountAmount,
      'cgst': cgst,
      'sgst': sgst,
      'igst': igst,
      'total_gst': totalGst,
      'grand_total': grandTotal,
      'round_off': roundOff,
      'payment_mode': paymentMode,
      'status': status,
      'created_at': createdAt.millisecondsSinceEpoch,
    };
  }

  factory Invoice.fromMap(Map<String, dynamic> map) {
    return Invoice(
      id: map['id'] as int?,
      invoiceNumber: map['invoice_number'] as String,
      customerId: map['customer_id'] as int?,
      customerName: map['customer_name'] as String? ?? "Walk-in Customer",
      customerMobile: map['customer_mobile'] as String?,
      subtotal: (map['subtotal'] as num).toDouble(),
      discountAmount: (map['discount_amount'] as num?)?.toDouble() ?? 0.0,
      cgst: (map['cgst'] as num?)?.toDouble() ?? 0.0,
      sgst: (map['sgst'] as num?)?.toDouble() ?? 0.0,
      igst: (map['igst'] as num?)?.toDouble() ?? 0.0,
      totalGst: (map['total_gst'] as num?)?.toDouble() ?? 0.0,
      grandTotal: (map['grand_total'] as num).toDouble(),
      roundOff: (map['round_off'] as num?)?.toDouble() ?? 0.0,
      paymentMode: map['payment_mode'] as String? ?? "CASH",
      status: map['status'] as String? ?? "COMPLETED",
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
    );
  }
}

class InvoiceItem {
  final int? id;
  final int invoiceId;
  final int productId;
  final String productName;
  final String? barcode;
  final double quantity;
  final String unit;
  final double unitPrice;
  final double gstRate;
  final double totalAmount;

  InvoiceItem({
    this.id,
    required this.invoiceId,
    required this.productId,
    required this.productName,
    this.barcode,
    required this.quantity,
    this.unit = "pcs",
    required this.unitPrice,
    this.gstRate = 0.0,
    required this.totalAmount,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'invoice_id': invoiceId,
      'product_id': productId,
      'product_name': productName,
      'barcode': barcode,
      'quantity': quantity,
      'unit': unit,
      'unit_price': unitPrice,
      'gst_rate': gstRate,
      'total_amount': totalAmount,
    };
  }

  factory InvoiceItem.fromMap(Map<String, dynamic> map) {
    return InvoiceItem(
      id: map['id'] as int?,
      invoiceId: map['invoice_id'] as int,
      productId: map['product_id'] as int,
      productName: map['product_name'] as String,
      barcode: map['barcode'] as String?,
      quantity: (map['quantity'] as num).toDouble(),
      unit: map['unit'] as String? ?? "pcs",
      unitPrice: (map['unit_price'] as num).toDouble(),
      gstRate: (map['gst_rate'] as num?)?.toDouble() ?? 0.0,
      totalAmount: (map['total_amount'] as num).toDouble(),
    );
  }
}
