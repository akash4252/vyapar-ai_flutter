class Customer {
  final int? id;
  final String name;
  final String? mobile;
  final String? address;
  final String? gstin;
  final double currentCreditBalance;
  final double creditLimit;
  final int loyaltyPoints;
  final double totalSpent;
  final DateTime createdAt;

  Customer({
    this.id,
    required this.name,
    this.mobile,
    this.address,
    this.gstin,
    this.currentCreditBalance = 0.0,
    this.creditLimit = 5000.0,
    this.loyaltyPoints = 0,
    this.totalSpent = 0.0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'mobile': mobile,
      'address': address,
      'gstin': gstin,
      'current_credit_balance': currentCreditBalance,
      'credit_limit': creditLimit,
      'loyalty_points': loyaltyPoints,
      'total_spent': totalSpent,
      'created_at': createdAt.millisecondsSinceEpoch,
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] as String,
      mobile: map['mobile'] as String?,
      address: map['address'] as String?,
      gstin: map['gstin'] as String?,
      currentCreditBalance: (map['current_credit_balance'] as num?)?.toDouble() ?? 0.0,
      creditLimit: (map['credit_limit'] as num?)?.toDouble() ?? 5000.0,
      loyaltyPoints: map['loyalty_points'] as int? ?? 0,
      totalSpent: (map['total_spent'] as num?)?.toDouble() ?? 0.0,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
    );
  }

  Customer copyWith({
    int? id,
    String? name,
    String? mobile,
    String? address,
    String? gstin,
    double? currentCreditBalance,
    double? creditLimit,
    int? loyaltyPoints,
    double? totalSpent,
    DateTime? createdAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      address: address ?? this.address,
      gstin: gstin ?? this.gstin,
      currentCreditBalance: currentCreditBalance ?? this.currentCreditBalance,
      creditLimit: creditLimit ?? this.creditLimit,
      loyaltyPoints: loyaltyPoints ?? this.loyaltyPoints,
      totalSpent: totalSpent ?? this.totalSpent,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

class CustomerTransaction {
  final int? id;
  final int customerId;
  final String transactionType; // CREDIT_GIVEN, PAYMENT_RECEIVED
  final double amount;
  final double balanceAfter;
  final String? invoiceNumber;
  final String? note;
  final DateTime createdAt;

  CustomerTransaction({
    this.id,
    required this.customerId,
    required this.transactionType,
    required this.amount,
    required this.balanceAfter,
    this.invoiceNumber,
    this.note,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'transaction_type': transactionType,
      'amount': amount,
      'balance_after': balanceAfter,
      'invoice_number': invoiceNumber,
      'note': note,
      'created_at': createdAt.millisecondsSinceEpoch,
    };
  }

  factory CustomerTransaction.fromMap(Map<String, dynamic> map) {
    return CustomerTransaction(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      transactionType: map['transaction_type'] as String,
      amount: (map['amount'] as num).toDouble(),
      balanceAfter: (map['balance_after'] as num).toDouble(),
      invoiceNumber: map['invoice_number'] as String?,
      note: map['note'] as String?,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
    );
  }
}
