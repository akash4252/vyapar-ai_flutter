class Supplier {
  final int? id;
  final String name;
  final String? companyName;
  final String? mobile;
  final String? gstin;
  final double currentOutstanding;

  Supplier({
    this.id,
    required this.name,
    this.companyName,
    this.mobile,
    this.gstin,
    this.currentOutstanding = 0.0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'company_name': companyName,
      'mobile': mobile,
      'gstin': gstin,
      'current_outstanding': currentOutstanding,
    };
  }

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'] as int?,
      name: map['name'] as String,
      companyName: map['company_name'] as String?,
      mobile: map['mobile'] as String?,
      gstin: map['gstin'] as String?,
      currentOutstanding: (map['current_outstanding'] as num?)?.toDouble() ?? 0.0,
    );
  }
}

class Purchase {
  final int? id;
  final String purchaseNumber;
  final int supplierId;
  final String supplierName;
  final String? invoiceNumber;
  final double grandTotal;
  final double amountPaid;
  final String paymentStatus;
  final DateTime createdAt;

  Purchase({
    this.id,
    required this.purchaseNumber,
    required this.supplierId,
    required this.supplierName,
    this.invoiceNumber,
    required this.grandTotal,
    this.amountPaid = 0.0,
    this.paymentStatus = "PAID",
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'purchase_number': purchaseNumber,
      'supplier_id': supplierId,
      'supplier_name': supplierName,
      'invoice_number': invoiceNumber,
      'grand_total': grandTotal,
      'amount_paid': amountPaid,
      'payment_status': paymentStatus,
      'created_at': createdAt.millisecondsSinceEpoch,
    };
  }

  factory Purchase.fromMap(Map<String, dynamic> map) {
    return Purchase(
      id: map['id'] as int?,
      purchaseNumber: map['purchase_number'] as String,
      supplierId: map['supplier_id'] as int,
      supplierName: map['supplier_name'] as String,
      invoiceNumber: map['invoice_number'] as String?,
      grandTotal: (map['grand_total'] as num).toDouble(),
      amountPaid: (map['amount_paid'] as num?)?.toDouble() ?? 0.0,
      paymentStatus: map['payment_status'] as String? ?? "PAID",
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
    );
  }
}
