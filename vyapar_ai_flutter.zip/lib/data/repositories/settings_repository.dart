import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/settings.dart';

class SettingsRepository {
  final AppDatabase dbManager;
  SettingsRepository([AppDatabase? db]) : dbManager = db ?? AppDatabase.instance;

  Future<BusinessInfo?> getBusinessInfo() async {
    final db = await dbManager.database;
    final maps = await db.query('business', where: 'id = 1', limit: 1);
    if (maps.isEmpty) return null;
    return BusinessInfo.fromMap(maps.first);
  }

  Future<void> updateBusinessInfo(BusinessInfo info) async {
    final db = await dbManager.database;
    await db.insert('business', info.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
