import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/customer.dart';

class KhataRepository {
  final AppDatabase dbManager;
  KhataRepository([AppDatabase? db]) : dbManager = db ?? AppDatabase.instance;

  Future<List<Customer>> getAllCustomers() async {
    final db = await dbManager.database;
    final maps = await db.query('customers', orderBy: 'name ASC');
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  Future<Customer?> getCustomerById(int id) async {
    final db = await dbManager.database;
    final maps = await db.query('customers', where: 'id = ?', whereArgs: [id], limit: 1);
    if (maps.isEmpty) return null;
    return Customer.fromMap(maps.first);
  }

  Future<Customer?> findCustomerByName(String name) async {
    final db = await dbManager.database;
    final maps = await db.query('customers', where: 'name LIKE ?', whereArgs: ['%${name.trim()}%'], limit: 1);
    if (maps.isEmpty) return null;
    return Customer.fromMap(maps.first);
  }

  Future<List<CustomerTransaction>> getCustomerTransactions(int customerId) async {
    final db = await dbManager.database;
    final maps = await db.query('customer_transactions', where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'created_at DESC');
    return maps.map((m) => CustomerTransaction.fromMap(m)).toList();
  }

  Future<int> insertCustomer(Customer customer) async {
    final db = await dbManager.database;
    return await db.insert('customers', customer.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> addKhataEntry({
    required int customerId,
    required String type, // CREDIT_GIVEN or PAYMENT_RECEIVED
    required double amount,
    String? note,
  }) async {
    final db = await dbManager.database;
    await db.transaction((txn) async {
      final custRes = await txn.query('customers', where: 'id = ?', whereArgs: [customerId], limit: 1);
      if (custRes.isEmpty) return;

      final current = (custRes.first['current_credit_balance'] as num).toDouble();
      final newBalance = type == 'CREDIT_GIVEN' ? (current + amount) : (current - amount);

      await txn.update('customers', {
        'current_credit_balance': newBalance,
      }, where: 'id = ?', whereArgs: [customerId]);

      await txn.insert('customer_transactions', {
        'customer_id': customerId,
        'transaction_type': type,
        'amount': amount,
        'balance_after': newBalance,
        'note': note,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
    });
  }

  Future<double> getTotalOutstandingUdhaar() async {
    final db = await dbManager.database;
    final res = await db.rawQuery('SELECT SUM(current_credit_balance) as total FROM customers WHERE current_credit_balance > 0');
    return (res.first['total'] as num?)?.toDouble() ?? 0.0;
  }
}
