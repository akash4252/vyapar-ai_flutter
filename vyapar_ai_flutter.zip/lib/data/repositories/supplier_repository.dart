import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/supplier.dart';
import '../models/expense.dart';

class SupplierRepository {
  final AppDatabase dbManager;
  SupplierRepository([AppDatabase? db]) : dbManager = db ?? AppDatabase.instance;

  Future<List<Supplier>> getAllSuppliers() async {
    final db = await dbManager.database;
    final maps = await db.query('suppliers', orderBy: 'name ASC');
    return maps.map((m) => Supplier.fromMap(m)).toList();
  }

  Future<int> insertSupplier(Supplier supplier) async {
    final db = await dbManager.database;
    return await db.insert('suppliers', supplier.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Purchase>> getAllPurchases() async {
    final db = await dbManager.database;
    final maps = await db.query('purchases', orderBy: 'created_at DESC');
    return maps.map((m) => Purchase.fromMap(m)).toList();
  }

  Future<int> recordPurchase({
    required Purchase purchase,
    required List<Map<String, dynamic>> items,
  }) async {
    final db = await dbManager.database;
    return await db.transaction((txn) async {
      final pId = await txn.insert('purchases', purchase.toMap());

      for (final itm in items) {
        final pId = itm['productId'] as int;
        final qty = (itm['quantity'] as num).toDouble();
        await txn.rawUpdate('UPDATE products SET current_stock = current_stock + ? WHERE id = ?', [qty, pId]);
      }
      return pId;
    });
  }

  Future<List<Expense>> getAllExpenses() async {
    final db = await dbManager.database;
    final maps = await db.query('expenses', orderBy: 'date DESC');
    return maps.map((m) => Expense.fromMap(m)).toList();
  }

  Future<int> addExpense(Expense expense) async {
    final db = await dbManager.database;
    return await db.insert('expenses', expense.toMap());
  }

  Future<double> getTodayExpenses() async {
    final db = await dbManager.database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 0, 0, 0).millisecondsSinceEpoch;
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;

    final res = await db.rawQuery('SELECT SUM(amount) as total FROM expenses WHERE date >= ? AND date <= ?', [start, end]);
    return (res.first['total'] as num?)?.toDouble() ?? 0.0;
  }
}
