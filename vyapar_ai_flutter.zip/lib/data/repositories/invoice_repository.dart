import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/invoice.dart';

class InvoiceWithItems {
  final Invoice invoice;
  final List<InvoiceItem> items;

  InvoiceWithItems({required this.invoice, required this.items});
}

class InvoiceRepository {
  final AppDatabase dbManager;
  InvoiceRepository([AppDatabase? db]) : dbManager = db ?? AppDatabase.instance;

  Future<String> generateNextInvoiceNumber() async {
    final db = await dbManager.database;
    final res = await db.rawQuery('SELECT COUNT(*) as count FROM invoices');
    final count = (res.first['count'] as int? ?? 0) + 1;
    final year = DateTime.now().year;
    return "VX-$year-${count.toString().padLeft(6, '0')}";
  }

  /// Atomic POS Billing Transaction
  Future<String> processAtomicBill({
    required Invoice invoice,
    required List<InvoiceItem> items,
    int? customerId,
    bool isCredit = false,
  }) async {
    final db = await dbManager.database;

    return await db.transaction((txn) async {
      // 1. Insert Invoice
      final invoiceId = await txn.insert('invoices', invoice.toMap());

      // 2. Insert Invoice Items & Decrement Product Stock
      for (final item in items) {
        final itemMap = item.toMap();
        itemMap['invoice_id'] = invoiceId;
        await txn.insert('invoice_items', itemMap);

        await txn.rawUpdate('''
          UPDATE products 
          SET current_stock = current_stock - ? 
          WHERE id = ?
        ''', [item.quantity, item.productId]);
      }

      // 3. Update Customer Khata & Loyalty (if applicable)
      if (customerId != null) {
        if (isCredit) {
          final custRes = await txn.query('customers', where: 'id = ?', whereArgs: [customerId], limit: 1);
          if (custRes.isNotEmpty) {
            final currentBal = (custRes.first['current_credit_balance'] as num).toDouble();
            final newBal = currentBal + invoice.grandTotal;

            await txn.update('customers', {
              'current_credit_balance': newBal,
              'total_spent': (custRes.first['total_spent'] as num).toDouble() + invoice.grandTotal,
            }, where: 'id = ?', whereArgs: [customerId]);

            await txn.insert('customer_transactions', {
              'customer_id': customerId,
              'transaction_type': 'CREDIT_GIVEN',
              'amount': invoice.grandTotal,
              'balance_after': newBal,
              'invoice_number': invoice.invoiceNumber,
              'note': 'POS Credit Sale',
              'created_at': DateTime.now().millisecondsSinceEpoch,
            });
          }
        } else {
          // Accrue Loyalty (1 pt per Rs.100)
          final points = (invoice.grandTotal / 100).floor();
          if (points > 0) {
            await txn.rawUpdate('''
              UPDATE customers 
              SET loyalty_points = loyalty_points + ?, total_spent = total_spent + ?
              WHERE id = ?
            ''', [points, invoice.grandTotal, customerId]);
          }
        }
      }

      return invoice.invoiceNumber;
    });
  }

  Future<List<InvoiceWithItems>> getAllInvoices() async {
    final db = await dbManager.database;
    final invMaps = await db.query('invoices', orderBy: 'created_at DESC');

    final List<InvoiceWithItems> result = [];
    for (final map in invMaps) {
      final inv = Invoice.fromMap(map);
      final itemMaps = await db.query('invoice_items', where: 'invoice_id = ?', whereArgs: [inv.id]);
      final items = itemMaps.map((m) => InvoiceItem.fromMap(m)).toList();
      result.add(InvoiceWithItems(invoice: inv, items: items));
    }
    return result;
  }

  Future<InvoiceWithItems?> getInvoiceByNumber(String invoiceNumber) async {
    final db = await dbManager.database;
    final invMaps = await db.query('invoices', where: 'invoice_number = ?', whereArgs: [invoiceNumber], limit: 1);
    if (invMaps.isEmpty) return null;

    final inv = Invoice.fromMap(invMaps.first);
    final itemMaps = await db.query('invoice_items', where: 'invoice_id = ?', whereArgs: [inv.id]);
    final items = itemMaps.map((m) => InvoiceItem.fromMap(m)).toList();
    return InvoiceWithItems(invoice: inv, items: items);
  }

  Future<double> getSalesSumBetween(DateTime start, DateTime end) async {
    final db = await dbManager.database;
    final res = await db.rawQuery('''
      SELECT SUM(grand_total) as total FROM invoices 
      WHERE created_at >= ? AND created_at <= ? AND status = 'COMPLETED'
    ''', [start.millisecondsSinceEpoch, end.millisecondsSinceEpoch]);
    return (res.first['total'] as num?)?.toDouble() ?? 0.0;
  }

  Future<double> getTodaySales() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 0, 0, 0);
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59, 999);
    return getSalesSumBetween(start, end);
  }

  Future<int> getTodayBillCount() async {
    final db = await dbManager.database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 0, 0, 0).millisecondsSinceEpoch;
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59, 999).millisecondsSinceEpoch;

    final res = await db.rawQuery('''
      SELECT COUNT(*) as count FROM invoices 
      WHERE created_at >= ? AND created_at <= ? AND status = 'COMPLETED'
    ''', [start, end]);
    return res.first['count'] as int? ?? 0;
  }
}
