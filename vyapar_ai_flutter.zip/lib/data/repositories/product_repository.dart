import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/product.dart';

class ProductRepository {
  final AppDatabase dbManager;
  ProductRepository([AppDatabase? db]) : dbManager = db ?? AppDatabase.instance;

  Future<List<Product>> getAllProducts() async {
    final db = await dbManager.database;
    final List<Map<String, dynamic>> maps = await db.query('products', orderBy: 'name ASC');

    final List<Product> products = [];
    for (final map in maps) {
      final pId = map['id'] as int;
      final aliases = await getProductAliases(pId);
      products.add(Product.fromMap(map, aliases));
    }
    return products;
  }

  Future<Product?> getProductById(int id) async {
    final db = await dbManager.database;
    final maps = await db.query('products', where: 'id = ?', whereArgs: [id], limit: 1);
    if (maps.isEmpty) return null;
    final aliases = await getProductAliases(id);
    return Product.fromMap(maps.first, aliases);
  }

  Future<Product?> getProductByBarcode(String barcode) async {
    final db = await dbManager.database;
    final maps = await db.query('products', where: 'barcode = ?', whereArgs: [barcode], limit: 1);
    if (maps.isEmpty) return null;
    final id = maps.first['id'] as int;
    final aliases = await getProductAliases(id);
    return Product.fromMap(maps.first, aliases);
  }

  Future<List<Product>> searchProducts(String query) async {
    final db = await dbManager.database;
    final q = '%${query.trim()}%';
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT DISTINCT p.* FROM products p
      LEFT JOIN product_aliases a ON p.id = a.product_id
      WHERE p.name LIKE ? OR p.local_name LIKE ? OR p.barcode LIKE ? OR a.alias LIKE ?
    ''', [q, q, q, q]);

    final List<Product> products = [];
    for (final map in maps) {
      final pId = map['id'] as int;
      final aliases = await getProductAliases(pId);
      products.add(Product.fromMap(map, aliases));
    }
    return products;
  }

  Future<List<Product>> getLowStockProducts() async {
    final db = await dbManager.database;
    final maps = await db.rawQuery('SELECT * FROM products WHERE current_stock <= minimum_stock ORDER BY current_stock ASC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<int> insertProduct(Product product) async {
    final db = await dbManager.database;
    final id = await db.insert('products', product.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);

    for (final alias in product.aliases) {
      await db.insert('product_aliases', {'product_id': id, 'alias': alias.trim()});
    }
    return id;
  }

  Future<int> updateProduct(Product product) async {
    final db = await dbManager.database;
    final count = await db.update('products', product.toMap(), where: 'id = ?', whereArgs: [product.id]);

    await db.delete('product_aliases', where: 'product_id = ?', whereArgs: [product.id]);
    for (final alias in product.aliases) {
      await db.insert('product_aliases', {'product_id': product.id, 'alias': alias.trim()});
    }
    return count;
  }

  Future<int> updateStock(int productId, double newStock) async {
    final db = await dbManager.database;
    return await db.update('products', {'current_stock': newStock}, where: 'id = ?', whereArgs: [productId]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await dbManager.database;
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<String>> getProductAliases(int productId) async {
    final db = await dbManager.database;
    final maps = await db.query('product_aliases', where: 'product_id = ?', whereArgs: [productId]);
    return maps.map((m) => m['alias'] as String).toList();
  }
}
