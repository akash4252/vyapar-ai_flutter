import '../database/app_database.dart';
import '../models/product.dart';
import '../models/customer.dart';
import '../models/supplier.dart';
import '../repositories/product_repository.dart';
import '../repositories/khata_repository.dart';
import '../repositories/supplier_repository.dart';

class DemoDataPopulator {
  static Future<void> populateDemoData() async {
    final productRepo = ProductRepository();
    final khataRepo = KhataRepository();
    final supplierRepo = SupplierRepository();

    // 1. Demo Products with Voice Aliases
    final List<Product> demoProducts = [
      Product(
        name: "Maggi 2-Minute Noodles 70g",
        localName: "मॅगी / मैगी",
        barcode: "8901058852391",
        hsnCode: "19023010",
        purchasePrice: 11.50,
        sellingPrice: 14.00,
        mrp: 14.00,
        gstRate: 12.0,
        currentStock: 48.0,
        minimumStock: 10.0,
        maximumStock: 100.0,
        unit: "pcs",
        category: "Instant Food",
        brand: "Nestle",
        aliases: ["Maggi", "Maggie", "मैगी", "मॅगी", "नूडल्स", "noodles"],
      ),
      Product(
        name: "Madhur Pure & Hygienic Sugar",
        localName: "साखर / चीनी",
        barcode: "8906007280017",
        hsnCode: "17019990",
        purchasePrice: 38.00,
        sellingPrice: 44.00,
        mrp: 46.00,
        gstRate: 0.0,
        currentStock: 25.0,
        minimumStock: 10.0,
        maximumStock: 100.0,
        unit: "kg",
        category: "Staples",
        brand: "Madhur",
        aliases: ["Sugar", "साखर", "चीनी", "sakhar", "cheeni"],
      ),
      Product(
        name: "Amul Taaza Toned Milk 500ml",
        localName: "अमुल दूध",
        barcode: "8901262010051",
        hsnCode: "04012000",
        purchasePrice: 24.50,
        sellingPrice: 27.00,
        mrp: 27.00,
        gstRate: 0.0,
        currentStock: 18.0,
        minimumStock: 5.0,
        maximumStock: 50.0,
        unit: "pkt",
        category: "Dairy",
        brand: "Amul",
        aliases: ["Amul Milk", "दूध", "doodh", "dudh", "amul taaza"],
      ),
      Product(
        name: "Wagh Bakri Premium Tea 250g",
        localName: "वाघ बकरी चहा / चाय",
        barcode: "8901764012111",
        hsnCode: "09024020",
        purchasePrice: 110.00,
        sellingPrice: 130.00,
        mrp: 135.00,
        gstRate: 5.0,
        currentStock: 15.0,
        minimumStock: 5.0,
        maximumStock: 40.0,
        unit: "pkt",
        category: "Beverages",
        brand: "Wagh Bakri",
        aliases: ["Tea", "चहा", "चाय", "chai", "chaha", "wagh bakri"],
      ),
      Product(
        name: "Parle-G Gold Biscuits 1kg",
        localName: "पार्ले-जी बिस्किट",
        barcode: "8901719101037",
        hsnCode: "19053100",
        purchasePrice: 72.00,
        sellingPrice: 85.00,
        mrp: 90.00,
        gstRate: 18.0,
        currentStock: 20.0,
        minimumStock: 6.0,
        maximumStock: 50.0,
        unit: "pkt",
        category: "Snacks",
        brand: "Parle",
        aliases: ["Parle G", "बिस्किट", "biscuit", "parle"],
      ),
      Product(
        name: "Fortune Sunlite Sunflower Oil 1L",
        localName: "फॉर्च्युन तेल",
        barcode: "8906007281052",
        hsnCode: "15121910",
        purchasePrice: 128.00,
        sellingPrice: 145.00,
        mrp: 155.00,
        gstRate: 5.0,
        currentStock: 30.0,
        minimumStock: 8.0,
        maximumStock: 60.0,
        unit: "ltr",
        category: "Edible Oil",
        brand: "Fortune",
        aliases: ["Fortune Oil", "तेल", "oil", "tel", "sunflower oil"],
      ),
      Product(
        name: "Dettol Original Bathing Soap 125g",
        localName: "डेटॉल साबण",
        barcode: "8901396116001",
        hsnCode: "34011110",
        purchasePrice: 38.00,
        sellingPrice: 45.00,
        mrp: 48.00,
        gstRate: 18.0,
        currentStock: 35.0,
        minimumStock: 10.0,
        maximumStock: 80.0,
        unit: "pcs",
        category: "Personal Care",
        brand: "Dettol",
        aliases: ["Dettol", "साबण", "साबुन", "soap", "sabun"],
      ),
      Product(
        name: "Aashirvaad Superior MP Sharbati Atta 5kg",
        localName: "आशीर्वाद आटा / पीठ",
        barcode: "8901030383837",
        hsnCode: "11010000",
        purchasePrice: 220.00,
        sellingPrice: 255.00,
        mrp: 270.00,
        gstRate: 5.0,
        currentStock: 12.0,
        minimumStock: 5.0,
        maximumStock: 30.0,
        unit: "pkt",
        category: "Staples",
        brand: "Aashirvaad",
        aliases: ["Atta", "आटा", "पीठ", "gahu peeth", "aashirvaad"],
      ),
      Product(
        name: "Tata Salt Vacuum Evaporated 1kg",
        localName: "टाटा मीठ / नमक",
        barcode: "8901042958047",
        hsnCode: "25010010",
        purchasePrice: 22.00,
        sellingPrice: 28.00,
        mrp: 28.00,
        gstRate: 0.0,
        currentStock: 40.0,
        minimumStock: 10.0,
        maximumStock: 80.0,
        unit: "pkt",
        category: "Staples",
        brand: "Tata",
        aliases: ["Tata Salt", "मीठ", "नमक", "namak", "mith", "salt"],
      ),
      Product(
        name: "Surf Excel Easy Wash Detergent Powder 1kg",
        localName: "सर्फ एक्सेल पावडर",
        barcode: "8901030616126",
        hsnCode: "34029011",
        purchasePrice: 118.00,
        sellingPrice: 140.00,
        mrp: 149.00,
        gstRate: 18.0,
        currentStock: 4.0, // Low Stock trigger
        minimumStock: 8.0,
        maximumStock: 30.0,
        unit: "pkt",
        category: "Cleaning",
        brand: "Surf Excel",
        aliases: ["Surf Excel", "सर्फ", "धुलाई पावडर", "detergent", "surf"],
      ),
    ];

    for (final p in demoProducts) {
      await productRepo.insertProduct(p);
    }

    // 2. Demo Customers
    final List<Customer> demoCustomers = [
      Customer(
        name: "Rahul Sharma",
        mobile: "9823012345",
        address: "Flat 201, Shanti Heights, Pune",
        currentCreditBalance: 1250.0,
        creditLimit: 5000.0,
        loyaltyPoints: 125,
        totalSpent: 12500.0,
      ),
      Customer(
        name: "Amit Patil",
        mobile: "9823098765",
        address: "House 12, Ganesh Nagar, Pune",
        currentCreditBalance: 450.0,
        creditLimit: 3000.0,
        loyaltyPoints: 45,
        totalSpent: 4500.0,
      ),
      Customer(
        name: "Priya Kulkarni",
        mobile: "9823055443",
        address: "B-4, Laxmi Niwas, Pune",
        currentCreditBalance: 0.0,
        creditLimit: 10000.0,
        loyaltyPoints: 210,
        totalSpent: 21000.0,
      ),
      Customer(
        name: "Sneha Deshmukh",
        mobile: "9823077889",
        address: "Sai Park, Karve Road, Pune",
        currentCreditBalance: 820.0,
        creditLimit: 4000.0,
        loyaltyPoints: 80,
        totalSpent: 8200.0,
      ),
    ];

    for (final c in demoCustomers) {
      final custId = await khataRepo.insertCustomer(c);
      if (c.currentCreditBalance > 0) {
        await khataRepo.addKhataEntry(
          customerId: custId,
          type: 'CREDIT_GIVEN',
          amount: c.currentCreditBalance,
          note: 'Opening Udhaar Balance',
        );
      }
    }

    // 3. Demo Suppliers
    final List<Supplier> demoSuppliers = [
      Supplier(
        name: "ABC Distributors",
        companyName: "ABC FMCG Logistics Pvt Ltd",
        mobile: "9822011223",
        gstin: "27AABCA1234F1Z1",
        currentOutstanding: 4500.0,
      ),
      Supplier(
        name: "Maharashtra Wholesale Mart",
        companyName: "Maharashtra Grain Traders",
        mobile: "9822044556",
        gstin: "27BCCDE5678G2Z3",
        currentOutstanding: 0.0,
      ),
    ];

    for (final s in demoSuppliers) {
      await supplierRepo.insertSupplier(s);
    }
  }
}
