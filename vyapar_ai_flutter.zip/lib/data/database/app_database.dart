import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/product.dart';
import '../models/customer.dart';
import '../models/invoice.dart';
import '../models/supplier.dart';
import '../models/expense.dart';
import '../models/settings.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('vyapar_ai_offline.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    // 1. Business Table
    await db.execute('''
      CREATE TABLE business (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        trade_name TEXT,
        gstin TEXT,
        mobile TEXT,
        address TEXT,
        upi_id TEXT,
        shop_type TEXT DEFAULT 'Kirana Store'
      )
    ''');

    // 2. Products Table
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        local_name TEXT,
        barcode TEXT UNIQUE,
        hsn_code TEXT,
        purchase_price REAL NOT NULL,
        selling_price REAL NOT NULL,
        mrp REAL NOT NULL,
        gst_rate REAL DEFAULT 0.0,
        is_tax_inclusive INTEGER DEFAULT 1,
        current_stock REAL DEFAULT 0.0,
        minimum_stock REAL DEFAULT 5.0,
        maximum_stock REAL DEFAULT 100.0,
        unit TEXT DEFAULT 'pcs',
        category TEXT,
        brand TEXT
      )
    ''');

    // 3. Product Aliases Table (for Voice Matching)
    await db.execute('''
      CREATE TABLE product_aliases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        alias TEXT NOT NULL,
        language TEXT DEFAULT 'EN',
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
      )
    ''');

    // 4. Customers Table
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT,
        address TEXT,
        gstin TEXT,
        current_credit_balance REAL DEFAULT 0.0,
        credit_limit REAL DEFAULT 5000.0,
        loyalty_points INTEGER DEFAULT 0,
        total_spent REAL DEFAULT 0.0,
        created_at INTEGER NOT NULL
      )
    ''');

    // 5. Customer Transactions (Khata Ledger)
    await db.execute('''
      CREATE TABLE customer_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        transaction_type TEXT NOT NULL,
        amount REAL NOT NULL,
        balance_after REAL NOT NULL,
        invoice_number TEXT,
        note TEXT,
        created_at INTEGER NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE
      )
    ''');

    // 6. Invoices Table
    await db.execute('''
      CREATE TABLE invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_number TEXT UNIQUE NOT NULL,
        customer_id INTEGER,
        customer_name TEXT NOT NULL,
        customer_mobile TEXT,
        subtotal REAL NOT NULL,
        discount_amount REAL DEFAULT 0.0,
        cgst REAL DEFAULT 0.0,
        sgst REAL DEFAULT 0.0,
        igst REAL DEFAULT 0.0,
        total_gst REAL DEFAULT 0.0,
        grand_total REAL NOT NULL,
        round_off REAL DEFAULT 0.0,
        payment_mode TEXT DEFAULT 'CASH',
        status TEXT DEFAULT 'COMPLETED',
        created_at INTEGER NOT NULL
      )
    ''');

    // 7. Invoice Items Table
    await db.execute('''
      CREATE TABLE invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        barcode TEXT,
        quantity REAL NOT NULL,
        unit TEXT DEFAULT 'pcs',
        unit_price REAL NOT NULL,
        gst_rate REAL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        FOREIGN KEY (invoice_id) REFERENCES invoices (id) ON DELETE CASCADE
      )
    ''');

    // 8. Suppliers Table
    await db.execute('''
      CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        company_name TEXT,
        mobile TEXT,
        gstin TEXT,
        current_outstanding REAL DEFAULT 0.0
      )
    ''');

    // 9. Purchases Table
    await db.execute('''
      CREATE TABLE purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_number TEXT NOT NULL,
        supplier_id INTEGER NOT NULL,
        supplier_name TEXT NOT NULL,
        invoice_number TEXT,
        grand_total REAL NOT NULL,
        amount_paid REAL DEFAULT 0.0,
        payment_status TEXT DEFAULT 'PAID',
        created_at INTEGER NOT NULL
      )
    ''');

    // 10. Expenses Table
    await db.execute('''
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        date INTEGER NOT NULL
      )
    ''');

    // Pre-populate Default Store Info
    await db.insert('business', {
      'id': 1,
      'name': 'Shree Ganesh General Store',
      'trade_name': 'Shree Ganesh Retailers',
      'gstin': '27ABCDE1234F1Z5',
      'mobile': '9876543210',
      'address': 'Shop No. 4, MG Road, Pune, Maharashtra 411001',
      'upi_id': 'shreeganesh@upi',
      'shop_type': 'Kirana Store',
    });
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
