import 'package:flutter/material.dart';
import '../data/repositories/invoice_repository.dart';
import '../data/repositories/supplier_repository.dart';

class ReportProvider extends ChangeNotifier {
  final InvoiceRepository invoiceRepo;
  final SupplierRepository supplierRepo;

  ReportProvider({InvoiceRepository? invRepo, SupplierRepository? supRepo})
      : invoiceRepo = invRepo ?? InvoiceRepository(),
        supplierRepo = supRepo ?? SupplierRepository();

  double _todaySales = 0.0;
  int _todayBillCount = 0;
  double _todayExpenses = 0.0;
  List<InvoiceWithItems> _allInvoices = [];
  bool _isLoading = false;

  double get todaySales => _todaySales;
  int get todayBillCount => _todayBillCount;
  double get todayExpenses => _todayExpenses;
  double get todayGrossProfit => _todaySales * 0.20; // Avg 20% retail margin
  double get todayNetProfit => (todayGrossProfit - _todayExpenses);
  List<InvoiceWithItems> get allInvoices => _allInvoices;
  bool get isLoading => _isLoading;

  Future<void> loadDashboardMetrics() async {
    _isLoading = true;
    notifyListeners();

    _todaySales = await invoiceRepo.getTodaySales();
    _todayBillCount = await invoiceRepo.getTodayBillCount();
    _todayExpenses = await supplierRepo.getTodayExpenses();
    _allInvoices = await invoiceRepo.getAllInvoices();

    _isLoading = false;
    notifyListeners();
  }
}
