import 'package:flutter/material.dart';
import '../data/models/product.dart';
import '../data/models/customer.dart';
import '../data/models/invoice.dart';
import '../data/repositories/invoice_repository.dart';
import '../data/repositories/product_repository.dart';

class CartItem {
  final Product product;
  double quantity;
  double unitPrice;
  double discount;

  CartItem({
    required this.product,
    this.quantity = 1.0,
    double? unitPrice,
    this.discount = 0.0,
  }) : unitPrice = unitPrice ?? product.sellingPrice;

  double get subtotal => quantity * unitPrice;
  double get total => subtotal - discount;
  double get gstRate => product.gstRate;
}

class BillingProvider extends ChangeNotifier {
  final InvoiceRepository invoiceRepo;
  final ProductRepository productRepo;

  BillingProvider({InvoiceRepository? invRepo, ProductRepository? prodRepo})
      : invoiceRepo = invRepo ?? InvoiceRepository(),
        productRepo = prodRepo ?? ProductRepository();

  final List<CartItem> _cartItems = [];
  Customer? _selectedCustomer;
  double _billDiscount = 0.0;
  String _paymentMode = "CASH";
  bool _isProcessing = false;

  List<CartItem> get cartItems => List.unmodifiable(_cartItems);
  Customer? get selectedCustomer => _selectedCustomer;
  double get billDiscount => _billDiscount;
  String get paymentMode => _paymentMode;
  bool get isProcessing => _isProcessing;

  int get totalItemCount => _cartItems.length;

  double get subtotal => _cartItems.fold(0.0, (sum, item) => sum + item.total);

  double get totalTaxableAmount {
    double total = 0.0;
    for (final item in _cartItems) {
      if (item.product.isTaxInclusive) {
        total += item.total / (1 + (item.gstRate / 100));
      } else {
        total += item.total;
      }
    }
    return total;
  }

  double get totalGstAmount {
    double total = 0.0;
    for (final item in _cartItems) {
      if (item.product.isTaxInclusive) {
        final taxable = item.total / (1 + (item.gstRate / 100));
        total += item.total - taxable;
      } else {
        total += item.total * (item.gstRate / 100);
      }
    }
    return total;
  }

  double get grandTotal => (subtotal - _billDiscount).clamp(0.0, double.infinity);

  void selectCustomer(Customer? customer) {
    _selectedCustomer = customer;
    notifyListeners();
  }

  void setPaymentMode(String mode) {
    _paymentMode = mode;
    notifyListeners();
  }

  void setBillDiscount(double discount) {
    _billDiscount = discount;
    notifyListeners();
  }

  void addToCart(Product product, {double quantity = 1.0, double? price}) {
    final index = _cartItems.indexWhere((item) => item.product.id == product.id);
    if (index >= 0) {
      _cartItems[index].quantity += quantity;
      if (price != null) _cartItems[index].unitPrice = price;
    } else {
      _cartItems.add(CartItem(
        product: product,
        quantity: quantity,
        unitPrice: price ?? product.sellingPrice,
      ));
    }
    notifyListeners();
  }

  void updateQuantity(int index, double quantity) {
    if (index >= 0 && index < _cartItems.length) {
      if (quantity <= 0) {
        _cartItems.removeAt(index);
      } else {
        _cartItems[index].quantity = quantity;
      }
      notifyListeners();
    }
  }

  void removeFromCart(int index) {
    if (index >= 0 && index < _cartItems.length) {
      _cartItems.removeAt(index);
      notifyListeners();
    }
  }

  void clearCart() {
    _cartItems.clear();
    _selectedCustomer = null;
    _billDiscount = 0.0;
    _paymentMode = "CASH";
    notifyListeners();
  }

  Future<String?> checkout() async {
    if (_cartItems.isEmpty) return null;

    _isProcessing = true;
    notifyListeners();

    try {
      final invoiceNumber = await invoiceRepo.generateNextInvoiceNumber();
      final gst = totalGstAmount;
      final cgst = gst / 2;
      final sgst = gst / 2;

      final invoice = Invoice(
        invoiceNumber: invoiceNumber,
        customerId: _selectedCustomer?.id,
        customerName: _selectedCustomer?.name ?? "Walk-in Customer",
        customerMobile: _selectedCustomer?.mobile,
        subtotal: subtotal,
        discountAmount: _billDiscount,
        cgst: cgst,
        sgst: sgst,
        totalGst: gst,
        grandTotal: grandTotal,
        paymentMode: _paymentMode,
      );

      final List<InvoiceItem> invoiceItems = _cartItems.map((c) {
        return InvoiceItem(
          invoiceId: 0,
          productId: c.product.id!,
          productName: c.product.name,
          barcode: c.product.barcode,
          quantity: c.quantity,
          unit: c.product.unit,
          unitPrice: c.unitPrice,
          gstRate: c.gstRate,
          totalAmount: c.total,
        );
      }).toList();

      final createdInvoiceNumber = await invoiceRepo.processAtomicBill(
        invoice: invoice,
        items: invoiceItems,
        customerId: _selectedCustomer?.id,
        isCredit: _paymentMode == "CREDIT",
      );

      clearCart();
      _isProcessing = false;
      notifyListeners();
      return createdInvoiceNumber;
    } catch (e) {
      _isProcessing = false;
      notifyListeners();
      rethrow;
    }
  }
}
