import 'package:flutter/material.dart';
import '../data/models/product.dart';
import '../data/repositories/product_repository.dart';

class ProductProvider extends ChangeNotifier {
  final ProductRepository repository;

  ProductProvider({ProductRepository? repo}) : repository = repo ?? ProductRepository();

  List<Product> _products = [];
  List<Product> _lowStockProducts = [];
  bool _isLoading = false;
  String _searchQuery = "";

  List<Product> get products {
    if (_searchQuery.isEmpty) return _products;
    return _products.where((p) {
      final q = _searchQuery.toLowerCase();
      return p.name.toLowerCase().contains(q) ||
          (p.localName?.toLowerCase().contains(q) ?? false) ||
          (p.barcode?.contains(q) ?? false) ||
          p.aliases.any((a) => a.toLowerCase().contains(q));
    }).toList();
  }

  List<Product> get lowStockProducts => _lowStockProducts;
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;

  Future<void> loadProducts() async {
    _isLoading = true;
    notifyListeners();

    _products = await repository.getAllProducts();
    _lowStockProducts = await repository.getLowStockProducts();

    _isLoading = false;
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  Future<Product?> findProductByBarcode(String barcode) async {
    return await repository.getProductByBarcode(barcode);
  }

  Future<void> addProduct(Product product) async {
    await repository.insertProduct(product);
    await loadProducts();
  }

  Future<void> updateProduct(Product product) async {
    await repository.updateProduct(product);
    await loadProducts();
  }

  Future<void> updateStock(int productId, double newStock) async {
    await repository.updateStock(productId, newStock);
    await loadProducts();
  }

  Future<void> deleteProduct(int id) async {
    await repository.deleteProduct(id);
    await loadProducts();
  }
}
