import 'package:flutter/material.dart';
import '../data/models/settings.dart';
import '../data/repositories/settings_repository.dart';
import '../data/demo/demo_data_populator.dart';

class SettingsProvider extends ChangeNotifier {
  final SettingsRepository repository;

  SettingsProvider({SettingsRepository? repo}) : repository = repo ?? SettingsRepository();

  BusinessInfo? _businessInfo;
  String _language = "EN"; // EN, HI, MR
  String _paperWidth = "58mm"; // 58mm, 80mm

  BusinessInfo? get businessInfo => _businessInfo;
  String get language => _language;
  String get paperWidth => _paperWidth;

  Future<void> loadSettings() async {
    _businessInfo = await repository.getBusinessInfo();
    notifyListeners();
  }

  void setLanguage(String lang) {
    _language = lang;
    notifyListeners();
  }

  void setPaperWidth(String width) {
    _paperWidth = width;
    notifyListeners();
  }

  Future<void> updateBusiness(BusinessInfo info) async {
    await repository.updateBusinessInfo(info);
    _businessInfo = info;
    notifyListeners();
  }

  Future<void> reloadDemoStore() async {
    await DemoDataPopulator.populateDemoData();
    await loadSettings();
  }
}
