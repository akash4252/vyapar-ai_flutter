import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../data/models/customer.dart';
import '../data/repositories/khata_repository.dart';
import '../core/utils/currency_formatter.dart';

class KhataProvider extends ChangeNotifier {
  final KhataRepository repository;

  KhataProvider({KhataRepository? repo}) : repository = repo ?? KhataRepository();

  List<Customer> _customers = [];
  double _totalOutstanding = 0.0;
  bool _isLoading = false;
  String _searchQuery = "";

  List<Customer> get customers {
    if (_searchQuery.isEmpty) return _customers;
    final q = _searchQuery.toLowerCase();
    return _customers.where((c) => c.name.toLowerCase().contains(q) || (c.mobile?.contains(q) ?? false)).toList();
  }

  double get totalOutstanding => _totalOutstanding;
  bool get isLoading => _isLoading;

  Future<void> loadKhata() async {
    _isLoading = true;
    notifyListeners();

    _customers = await repository.getAllCustomers();
    _totalOutstanding = await repository.getTotalOutstandingUdhaar();

    _isLoading = false;
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  Future<void> addCustomer(Customer customer) async {
    await repository.insertCustomer(customer);
    await loadKhata();
  }

  Future<void> addKhataTransaction({
    required int customerId,
    required String type,
    required double amount,
    String? note,
  }) async {
    await repository.addKhataEntry(customerId: customerId, type: type, amount: amount, note: note);
    await loadKhata();
  }

  Future<void> sendWhatsAppReminder(Customer customer, String storeName) async {
    if (customer.mobile == null || customer.mobile!.isEmpty) return;

    final phone = customer.mobile!.replaceAll(RegExp(r'[^0-9]'), '');
    final fullPhone = phone.length == 10 ? "91$phone" : phone;

    final text = "Namaste ${customer.name} ji, this is a polite reminder from *$storeName*. Your pending Khata balance is *${CurrencyFormatter.format(customer.currentCreditBalance)}*. Kindly settle at your convenience. Thank you!";
    final uri = Uri.parse("https://api.whatsapp.com/send?phone=$fullPhone&text=${Uri.encodeComponent(text)}");

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}
