import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/voice/voice_parser_engine.dart';
import 'custom_buttons.dart';

class VoiceConfirmationSheet extends StatelessWidget {
  final String spokenText;
  final VoiceCommandResult parsedResult;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  const VoiceConfirmationSheet({
    super.key,
    required this.spokenText,
    required this.parsedResult,
    required this.onConfirm,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.secondaryAmber.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.mic, color: AppColors.secondaryDark, size: 24),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Voice Recognized / ओळखलेले संभाषण", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text("Verify before adding to bill", style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surfaceVariantLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '"$spokenText"',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, fontStyle: FontStyle.italic),
            ),
          ),
          const SizedBox(height: 16),
          if (parsedResult is BillingVoiceCommand) ...[
            const Text("Items Extracted:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 6),
            ...(parsedResult as BillingVoiceCommand).items.map((item) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("• ${item.productName}", style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text(
                      "${item.quantity.toStringAsFixed(0)} ${item.unit}${item.price != null ? ' @ ₹${item.price}' : ''}",
                      style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen),
                    ),
                  ],
                ),
              );
            }),
          ] else if (parsedResult is KhataCreditVoiceCommand) ...[
            Text(
              "Khata Credit: ${(parsedResult as KhataCreditVoiceCommand).customerName} ➔ ₹${(parsedResult as KhataCreditVoiceCommand).amount}",
              style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.error),
            ),
          ],
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onCancel,
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text("Cancel / रद्द करा"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: onConfirm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text("Confirm / होय", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
