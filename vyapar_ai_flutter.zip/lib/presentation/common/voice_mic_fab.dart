import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

class VoiceMicFab extends StatelessWidget {
  final VoidCallback onPressed;
  final bool isListening;

  const VoiceMicFab({
    super.key,
    required this.onPressed,
    this.isListening = false,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: onPressed,
      backgroundColor: isListening ? AppColors.error : AppColors.secondaryAmber,
      foregroundColor: Colors.white,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      icon: Icon(isListening ? Icons.mic : Icons.mic_none, size: 26),
      label: Text(
        isListening ? "Listening..." : "Speak Bill / बोलून बिल",
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
      ),
    );
  }
}
