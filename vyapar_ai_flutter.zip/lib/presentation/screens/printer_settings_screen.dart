import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:printing/printing.dart';
import '../../core/theme/app_colors.dart';
import '../../core/printer/thermal_escpos_driver.dart';
import '../../providers/settings_provider.dart';
import '../common/custom_buttons.dart';

class PrinterSettingsScreen extends StatefulWidget {
  const PrinterSettingsScreen({super.key});

  @override
  State<PrinterSettingsScreen> createState() => _PrinterSettingsScreenState();
}

class _PrinterSettingsScreenState extends State<PrinterSettingsScreen> {
  String _paperWidth = "58mm";

  @override
  void initState() {
    super.initState();
    _paperWidth = context.read<SettingsProvider>().paperWidth;
  }

  void _testPrint() async {
    final settings = context.read<SettingsProvider>();
    final biz = settings.businessInfo;

    final bytes = ThermalEscPosDriver.formatThermalReceipt(
      businessName: biz?.name ?? "VYAPAR AI TEST PRINT",
      address: biz?.address ?? "Thermal Configuration",
      mobile: biz?.mobile,
      gstin: biz?.gstin,
      invoiceNumber: "TEST-0001",
      date: "27/08/2026",
      customerName: "Test Customer",
      items: [
        {'name': 'Maggi 70g', 'qty': 2, 'price': 14.0, 'total': 28.0},
        {'name': 'Sugar 1kg', 'qty': 1, 'price': 44.0, 'total': 44.0},
      ],
      subtotal: 72.0,
      discount: 0.0,
      gst: 0.0,
      grandTotal: 72.0,
      paymentMethod: "CASH",
      paperWidth: _paperWidth == "58mm" ? ThermalPaperWidth.mm58 : ThermalPaperWidth.mm80,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Test receipt generated successfully!"), backgroundColor: AppColors.primaryGreen),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Thermal Printer / प्रिंटर सेटिंग्ज"),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: "TEST PRINT RECEIPT / चाचणी प्रिंट",
            icon: Icons.print,
            onClick: _testPrint,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Receipt Paper Width", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),

          Row(
            children: [
              Expanded(
                child: ChoiceChip(
                  label: const Text("58mm (2-inch Thermal)"),
                  selected: _paperWidth == "58mm",
                  onSelected: (val) {
                    setState(() => _paperWidth = "58mm");
                    context.read<SettingsProvider>().setPaperWidth("58mm");
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ChoiceChip(
                  label: const Text("80mm (3-inch Thermal)"),
                  selected: _paperWidth == "80mm",
                  onSelected: (val) {
                    setState(() => _paperWidth = "80mm");
                    context.read<SettingsProvider>().setPaperWidth("80mm");
                  },
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),
          const Text("Bluetooth Thermal Printers", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            color: AppColors.surfaceVariantLight,
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.bluetooth, color: AppColors.primaryGreen),
                      SizedBox(width: 8),
                      Text("Direct Bluetooth & USB SPP Support", style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  SizedBox(height: 6),
                  Text(
                    "Pairs with all standard Indian retail thermal POS printers (TVS, Everycom, NGX, POS-58, POS-80).",
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
