import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/models/product.dart';
import '../../data/models/supplier.dart';
import '../../data/repositories/supplier_repository.dart';
import '../../providers/product_provider.dart';
import '../common/custom_buttons.dart';

class NewPurchaseScreen extends StatefulWidget {
  const NewPurchaseScreen({super.key});

  @override
  State<NewPurchaseScreen> createState() => _NewPurchaseScreenState();
}

class _NewPurchaseScreenState extends State<NewPurchaseScreen> {
  final SupplierRepository _supplierRepo = SupplierRepository();
  List<Supplier> _suppliers = [];
  Supplier? _selectedSupplier;
  final TextEditingController _invoiceNumController = TextEditingController();

  final List<Map<String, dynamic>> _inwardItems = [];
  Product? _selectedProduct;
  final TextEditingController _qtyController = TextEditingController(text: "10");
  final TextEditingController _priceController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSuppliers();
  }

  Future<void> _loadSuppliers() async {
    final list = await _supplierRepo.getAllSuppliers();
    setState(() {
      _suppliers = list;
      if (list.isNotEmpty) _selectedSupplier = list.first;
    });
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();
    final totalAmount = _inwardItems.fold(0.0, (sum, i) => sum + ((i['quantity'] as num) * (i['price'] as num)));

    return Scaffold(
      appBar: AppBar(
        title: const Text("New Stock Purchase / खरेदी नोंद"),
      ),
      bottomNavigationBar: _inwardItems.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: SafeArea(
                child: VyaparPrimaryButton(
                  text: "CONFIRM PURCHASE (${CurrencyFormatter.format(totalAmount)})",
                  onClick: () async {
                    if (_selectedSupplier != null && _inwardItems.isNotEmpty) {
                      final purchase = Purchase(
                        purchaseNumber: "PO-${DateTime.now().millisecondsSinceEpoch % 100000}",
                        supplierId: _selectedSupplier!.id!,
                        supplierName: _selectedSupplier!.name,
                        invoiceNumber: _invoiceNumController.text.trim().isEmpty ? null : _invoiceNumController.text.trim(),
                        grandTotal: totalAmount,
                        amountPaid: totalAmount,
                      );

                      await _supplierRepo.recordPurchase(purchase: purchase, items: _inwardItems);
                      await productProvider.loadProducts();

                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Purchase recorded & stock updated!"), backgroundColor: AppColors.primaryGreen),
                        );
                        Navigator.pop(context);
                      }
                    }
                  },
                ),
              ),
            ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<Supplier>(
            value: _selectedSupplier,
            decoration: const InputDecoration(labelText: "Select Supplier *"),
            items: _suppliers.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
            onChanged: (val) => setState(() => _selectedSupplier = val),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _invoiceNumController,
            decoration: const InputDecoration(labelText: "Supplier Invoice Number"),
          ),
          const SizedBox(height: 20),
          const Text("Add Stock Items / वस्तू जोडा", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            color: AppColors.surfaceVariantLight,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  DropdownButtonFormField<Product>(
                    value: _selectedProduct,
                    decoration: const InputDecoration(labelText: "Select Product"),
                    items: productProvider.products.map((p) => DropdownMenuItem(value: p, child: Text(p.name))).toList(),
                    onChanged: (val) {
                      setState(() {
                        _selectedProduct = val;
                        _priceController.text = val?.purchasePrice.toString() ?? "";
                      });
                    },
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _qtyController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: "Quantity"),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: _priceController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: "Purchase Rate (₹)"),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryGreen),
                      onPressed: () {
                        final p = _selectedProduct;
                        final qty = double.tryParse(_qtyController.text);
                        final price = double.tryParse(_priceController.text);
                        if (p != null && qty != null && price != null) {
                          setState(() {
                            _inwardItems.add({
                              'productId': p.id,
                              'productName': p.name,
                              'quantity': qty,
                              'price': price,
                              'unit': p.unit,
                            });
                            _selectedProduct = null;
                            _qtyController.text = "10";
                            _priceController.clear();
                          });
                        }
                      },
                      icon: const Icon(Icons.add),
                      label: const Text("Add to List"),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),
          const Text("Inward Item List", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 8),

          ..._inwardItems.asMap().entries.map((entry) {
            final idx = entry.key;
            final item = entry.value;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                title: Text(item['productName'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("${item['quantity']} ${item['unit']} @ ₹${item['price']}"),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, color: AppColors.error),
                  onPressed: () => setState(() => _inwardItems.removeAt(idx)),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
