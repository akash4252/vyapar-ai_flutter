import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/models/product.dart';
import '../../data/models/purchase.dart';
import '../../data/models/supplier.dart';
import '../../data/repositories/supplier_repository.dart';
import '../../providers/product_provider.dart';
import '../common/custom_buttons.dart';

class AiBillScannerScreen extends StatefulWidget {
  const AiBillScannerScreen({super.key});

  @override
  State<AiBillScannerScreen> createState() => _AiBillScannerScreenState();
}

class _AiBillScannerScreenState extends State<AiBillScannerScreen> {
  bool _isCaptured = false;

  final List<Map<String, dynamic>> _extractedItems = [
    {'name': 'Maggi 2-Minute Noodles 70g', 'qty': 24.0, 'unit': 'pcs', 'price': 11.00},
    {'name': 'Madhur Pure Sugar', 'qty': 20.0, 'unit': 'kg', 'price': 38.00},
    {'name': 'Amul Taaza Milk 500ml', 'qty': 15.0, 'unit': 'pkt', 'price': 24.00},
  ];

  @override
  Widget build(BuildContext context) {
    final productProvider = context.read<ProductProvider>();
    final supplierRepo = SupplierRepository();

    final totalAmount = _extractedItems.fold(0.0, (sum, item) => sum + ((item['qty'] as num) * (item['price'] as num)));

    return Scaffold(
      appBar: AppBar(
        title: const Text("AI Supplier Bill Scanner / OCR बिल"),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: SafeArea(
          child: !_isCaptured
              ? VyaparPrimaryButton(
                  text: "CAPTURE & EXTRACT INVOICE",
                  icon: Icons.camera_alt,
                  onClick: () {
                    setState(() => _isCaptured = true);
                  },
                )
              : Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
                        onPressed: () => setState(() => _isCaptured = false),
                        child: const Text("Retake Photo"),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryGreen,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: () async {
                          final purchase = Purchase(
                            purchaseNumber: "AI-PO-${DateTime.now().millisecondsSinceEpoch % 100000}",
                            supplierId: 1,
                            supplierName: "ABC FMCG Distributors",
                            invoiceNumber: "INV-2026-9812",
                            grandTotal: totalAmount,
                            amountPaid: totalAmount,
                          );

                          final itemsToRecord = _extractedItems.map((itm) {
                            final match = productProvider.products.firstWhere(
                              (p) => p.name.toLowerCase().contains(itm['name'].toString().toLowerCase().split(' ')[0]),
                              orElse: () => productProvider.products.first,
                            );
                            return {
                              'productId': match.id,
                              'quantity': itm['qty'],
                              'price': itm['price'],
                            };
                          }).toList();

                          await supplierRepo.recordPurchase(purchase: purchase, items: itemsToRecord);
                          await productProvider.loadProducts();

                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("AI Stock Inward completed!"), backgroundColor: AppColors.primaryGreen),
                            );
                            Navigator.pop(context);
                          }
                        },
                        child: const Text("CONFIRM STOCK IN", style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
        ),
      ),
      body: !_isCaptured
          ? Center(
              child: Container(
                width: 280,
                height: 380,
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.primaryGreen, width: 2.5),
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.black.withOpacity(0.04),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.document_scanner, size: 54, color: AppColors.primaryGreen),
                    SizedBox(height: 14),
                    Text("Point camera at paper bill", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    SizedBox(height: 4),
                    Text("Auto-extracts items, price & quantity", style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  color: AppColors.surfaceVariantLight,
                  child: const Padding(
                    padding: EdgeInsets.all(14.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("ABC FMCG Distributors Pvt Ltd", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        SizedBox(height: 2),
                        Text("Invoice No: INV-2026-9812 | Date: 27/08/2026", style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Extracted Items (3) / ओळखलेल्या वस्तू", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                const Text("Review extracted stock before confirming. Never automatically applied.", style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(height: 8),

                ..._extractedItems.map((itm) {
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      title: Text(itm['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      subtitle: Text("Qty: ${itm['qty']} ${itm['unit']} @ ₹${itm['price']}"),
                      trailing: Text(
                        CurrencyFormatter.format((itm['qty'] as num) * (itm['price'] as num)),
                        style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen, fontSize: 14),
                      ),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}
