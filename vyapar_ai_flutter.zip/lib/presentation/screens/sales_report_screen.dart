import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/report_provider.dart';
import '../common/stat_card.dart';

class SalesReportScreen extends StatelessWidget {
  const SalesReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reports = context.watch<ReportProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Sales Analytics / विक्री अहवाल"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: StatCard(
                  title: "Today's Total Sales",
                  value: CurrencyFormatter.format(reports.todaySales),
                  subtitle: "${reports.todayBillCount} invoices generated",
                  icon: Icons.trending_up,
                  iconColor: AppColors.primaryGreen,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StatCard(
                  title: "Avg Bill Value",
                  value: CurrencyFormatter.format(reports.todayBillCount > 0 ? (reports.todaySales / reports.todayBillCount) : 0.0),
                  subtitle: "Per customer visit",
                  icon: Icons.receipt,
                  iconColor: AppColors.tertiaryBlue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text("Recent Completed Bills", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          ...reports.allInvoices.map((item) {
            final inv = item.invoice;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                title: Text(inv.customerName, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("${inv.invoiceNumber} • ${inv.paymentMode}"),
                trailing: Text(
                  CurrencyFormatter.format(inv.grandTotal),
                  style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen, fontSize: 15),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
