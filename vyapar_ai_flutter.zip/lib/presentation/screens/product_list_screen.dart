import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/product_provider.dart';
import '../common/product_row.dart';
import '../navigation/app_routes.dart';

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Product Directory / उत्पादने"),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            onPressed: () => Navigator.pushNamed(context, AppRoutes.barcodeScanner),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, AppRoutes.addEditProduct),
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Product / नवीन वस्तू"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: const InputDecoration(
                hintText: "Search by name, local name or barcode...",
                prefixIcon: Icon(Icons.search),
                contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
              onChanged: (val) => productProvider.setSearchQuery(val),
            ),
          ),
          Expanded(
            child: productProvider.products.isEmpty
                ? const Center(
                    child: Text("No products found.", style: TextStyle(color: AppColors.textSecondary)),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: productProvider.products.length,
                    itemBuilder: (ctx, idx) {
                      final p = productProvider.products[idx];
                      return ProductRow(
                        product: p,
                        onTap: () => Navigator.pushNamed(context, AppRoutes.addEditProduct, arguments: p),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
