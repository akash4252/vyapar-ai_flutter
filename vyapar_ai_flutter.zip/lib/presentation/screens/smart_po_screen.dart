import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/product_provider.dart';
import '../../providers/settings_provider.dart';
import '../common/custom_buttons.dart';

class SmartPoScreen extends StatelessWidget {
  const SmartPoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = context.watch<ProductProvider>();
    final settings = context.watch<SettingsProvider>();
    final lowStock = products.lowStockProducts;

    final suggestions = lowStock.map((p) {
      final needed = (p.maximumStock - p.currentStock).clamp(1.0, 1000.0);
      final cost = needed * p.purchasePrice;
      return {'product': p, 'needed': needed, 'cost': cost};
    }).toList();

    final totalEstimatedCost = suggestions.fold(0.0, (sum, s) => sum + (s['cost'] as double));

    Future<void> sendPoWhatsApp() async {
      final biz = settings.businessInfo;
      final buffer = StringBuffer();
      buffer.writeln("*PURCHASE ORDER — ${biz?.name ?? 'Store'}*");
      buffer.writeln("Please supply the following replenishment items:\n");

      for (int i = 0; i < suggestions.length; i++) {
        final s = suggestions[i];
        final p = s['product'] as dynamic;
        final needed = (s['needed'] as double).toInt();
        buffer.writeln("${i + 1}. *${p.name}* — $needed ${p.unit}");
      }
      buffer.writeln("\n*Estimated Total:* ${CurrencyFormatter.format(totalEstimatedCost)}");
      buffer.writeln("Thank you!");

      final uri = Uri.parse("https://api.whatsapp.com/send?text=${Uri.encodeComponent(buffer.toString())}");
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Smart Purchase Order / AI खरेदी"),
      ),
      bottomNavigationBar: suggestions.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: SafeArea(
                child: VyaparPrimaryButton(
                  text: "SHARE PO VIA WHATSAPP (${CurrencyFormatter.format(totalEstimatedCost)})",
                  icon: Icons.share,
                  onClick: sendPoWhatsApp,
                ),
              ),
            ),
      body: suggestions.isEmpty
          ? const Center(child: Text("All stocks optimal! No replenishment required."))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.secondaryAmber.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.auto_awesome, color: AppColors.secondaryDark),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "AI replenishment calculates the exact deficit up to maximum storage capacity.",
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF78350F)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Suggested Items for Reorder", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                ...suggestions.map((s) {
                  final p = s['product'] as dynamic;
                  final needed = (s['needed'] as double).toInt();
                  final cost = s['cost'] as double;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text("In Stock: ${p.currentStock.toInt()} ${p.unit} | Min Level: ${p.minimumStock.toInt()}"),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text("Order: +$needed ${p.unit}", style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen, fontSize: 14)),
                          Text(CurrencyFormatter.format(cost), style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}
