import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/models/customer.dart';
import '../../providers/khata_provider.dart';
import '../common/stat_card.dart';
import '../navigation/app_routes.dart';

class DigitalKhataScreen extends StatelessWidget {
  const DigitalKhataScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final khata = context.watch<KhataProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Digital Khata / उधारी वहीखाते"),
        actions: [
          IconButton(
            icon: const Icon(Icons.card_giftcard),
            tooltip: "Loyalty Points",
            onPressed: () => Navigator.pushNamed(context, AppRoutes.customerLoyalty),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _showAddCustomerDialog(context);
        },
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add),
        label: const Text("Add Customer / ग्राहक जोडा"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: StatCard(
              title: "Total Outstanding Udhaar",
              value: CurrencyFormatter.format(khata.totalOutstanding),
              subtitle = "${khata.customers.where((c) => c.currentCreditBalance > 0).length} customers with pending balance",
              icon: Icons.book,
              iconColor: AppColors.error,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextField(
              decoration: const InputDecoration(
                hintText: "Search customer name or mobile...",
                prefixIcon: Icon(Icons.search),
                contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
              onChanged: (val) => khata.setSearchQuery(val),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: khata.customers.isEmpty
                ? const Center(child: Text("No customers found.", style: TextStyle(color: AppColors.textSecondary)))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: khata.customers.length,
                    itemBuilder: (ctx, i) {
                      final c = khata.customers[i];
                      return Card(
                        elevation: 0.8,
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: ListTile(
                          onTap: () => Navigator.pushNamed(context, AppRoutes.customerProfile, arguments: c),
                          leading: CircleAvatar(
                            backgroundColor: AppColors.primaryGreen.withOpacity(0.12),
                            child: Text(c.name[0], style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen)),
                          ),
                          title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(c.mobile ?? "No phone recorded"),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                CurrencyFormatter.format(c.currentCreditBalance),
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                  color: c.currentCreditBalance > 0 ? AppColors.error : AppColors.primaryGreen,
                                ),
                              ),
                              Text(
                                c.currentCreditBalance > 0 ? "To Receive / बाकी" : "Settled / पूर्ण",
                                style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showAddCustomerDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final addressCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text("Add New Customer"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: "Customer Name *")),
              const SizedBox(height: 10),
              TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Mobile Number")),
              const SizedBox(height: 10),
              TextField(controller: addressCtrl, decoration: const InputDecoration(labelText: "Address / Colony")),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
            ElevatedButton(
              onPressed: () async {
                if (nameCtrl.text.trim().isNotEmpty) {
                  final cust = Customer(
                    name: nameCtrl.text.trim(),
                    mobile: phoneCtrl.text.trim().isEmpty ? null : phoneCtrl.text.trim(),
                    address: addressCtrl.text.trim().isEmpty ? null : addressCtrl.text.trim(),
                  );
                  await context.read<KhataProvider>().addCustomer(cust);
                  if (context.mounted) Navigator.pop(ctx);
                }
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }
}
