import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/product_provider.dart';
import '../../providers/khata_provider.dart';
import '../../providers/report_provider.dart';
import '../../providers/settings_provider.dart';
import '../navigation/app_routes.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _initApp();
  }

  Future<void> _initApp() async {
    final settingsProvider = context.read<SettingsProvider>();
    final productProvider = context.read<ProductProvider>();
    final khataProvider = context.read<KhataProvider>();
    final reportProvider = context.read<ReportProvider>();

    await settingsProvider.loadSettings();
    await productProvider.loadProducts();
    await khataProvider.loadKhata();
    await reportProvider.loadDashboardMetrics();

    // Auto-populate demo if first run and products are empty
    if (productProvider.products.isEmpty) {
      await settingsProvider.reloadDemoStore();
      await productProvider.loadProducts();
      await khataProvider.loadKhata();
      await reportProvider.loadDashboardMetrics();
    }

    await Future.delayed(const Duration(milliseconds: 1200));

    if (mounted) {
      Navigator.pushReplacementNamed(context, AppRoutes.dashboard);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryGreen,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(
                Icons.point_of_sale,
                size: 48,
                color: AppColors.primaryGreen,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "VYAPAR AI",
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "\"Bola. Scan Kiya. Bill Taiyar.\"",
              style: TextStyle(
                color: Colors.white.withOpacity(0.9),
                fontSize: 14,
                fontWeight: FontWeight.w500,
                fontStyle: FontStyle.italic,
              ),
            ),
            const SizedBox(height: 40),
            const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
            ),
          ],
        ),
      ),
    );
  }
}
