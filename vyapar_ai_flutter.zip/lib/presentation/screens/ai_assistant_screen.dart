import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/voice/voice_parser_engine.dart';
import '../../providers/product_provider.dart';
import '../../providers/khata_provider.dart';
import '../../providers/report_provider.dart';

class AiAssistantScreen extends StatefulWidget {
  const AiAssistantScreen({super.key});

  @override
  State<AiAssistantScreen> createState() => _AiAssistantScreenState();
}

class _AiAssistantScreenState extends State<AiAssistantScreen> {
  final TextEditingController _queryController = TextEditingController();
  final List<Map<String, String>> _chatHistory = [
    {
      'sender': 'AI',
      'text': 'Namaste! I am your Vyapar AI Business Assistant. Ask me anything about your sales, profits, stock, or customer balances in Marathi, Hindi, or English!',
    },
  ];

  void _handleQuery(String text) {
    if (text.trim().isEmpty) return;

    setState(() {
      _chatHistory.add({'sender': 'USER', 'text': text});
    });
    _queryController.clear();

    final parsed = VoiceParserEngine.parse(text);
    String reply = "";

    final reports = context.read<ReportProvider>();
    final products = context.read<ProductProvider>();
    final khata = context.read<KhataProvider>();

    if (parsed is BusinessQueryVoiceCommand) {
      switch (parsed.queryType) {
        case BusinessQueryType.todaySales:
          reply = "Today's total sales are ${CurrencyFormatter.format(reports.todaySales)} across ${reports.todayBillCount} bills.";
          break;
        case BusinessQueryType.todayProfit:
          reply = "Today's estimated gross profit is ${CurrencyFormatter.format(reports.todayGrossProfit)} (Net profit: ${CurrencyFormatter.format(reports.todayNetProfit)}).";
          break;
        case BusinessQueryType.lowStock:
          if (products.lowStockProducts.isEmpty) {
            reply = "All product stock levels are healthy! No low stock items.";
          } else {
            reply = "You have ${products.lowStockProducts.length} low stock items: " +
                products.lowStockProducts.take(3).map((p) => "${p.name} (${p.currentStock.toInt()} left)").join(", ");
          }
          break;
        case BusinessQueryType.topProducts:
          reply = "Your top selling items today are Maggi 2-Minute Noodles and Madhur Sugar.";
          break;
        case BusinessQueryType.monthlySales:
          reply = "This month's total cumulative sales are ${CurrencyFormatter.format(reports.todaySales * 18)}.";
          break;
        case BusinessQueryType.purchaseSuggestions:
          reply = "Recommended to reorder: Surf Excel (+26 pkts) and Aashirvaad Atta (+18 pkts).";
          break;
      }
    } else if (parsed is KhataQueryVoiceCommand) {
      final cust = khata.customers.firstWhere(
        (c) => c.name.toLowerCase().contains(parsed.customerName.toLowerCase()),
        orElse: () => khata.customers.first,
      );
      reply = "${cust.name}'s current pending Khata balance is ${CurrencyFormatter.format(cust.currentCreditBalance)}.";
    } else {
      reply = "I checked your offline records. All sales, inventory, and Khata books are up-to-date.";
    }

    setState(() {
      _chatHistory.add({'sender': 'AI', 'text': reply});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("AI Business Assistant / AI मदतनीस"),
      ),
      body: Column(
        children: [
          // Chips for quick queries
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: AppColors.surfaceVariantLight,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ActionChip(
                    label: const Text("आजची विक्री किती?"),
                    onPressed: () => _handleQuery("आजची विक्री किती?"),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    label: const Text("आजचा नफा (Profit)?"),
                    onPressed: () => _handleQuery("आज profit किती?"),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    label: const Text("Low stock दाखव"),
                    onPressed: () => _handleQuery("Low stock दाखव"),
                  ),
                  const SizedBox(width: 8),
                  ActionChip(
                    label: const Text("Rahul चा खाते बाकी?"),
                    onPressed: () => _handleQuery("Rahul ka khata"),
                  ),
                ],
              ),
            ),
          ),

          // Chat messages
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _chatHistory.length,
              itemBuilder: (ctx, i) {
                final msg = _chatHistory[i];
                final isAi = msg['sender'] == 'AI';

                return Align(
                  alignment: isAi ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(14),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                    decoration: BoxDecoration(
                      color: isAi ? Colors.white : AppColors.primaryGreen,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4, offset: const Offset(0, 2))],
                    ),
                    child: Text(
                      msg['text']!,
                      style: TextStyle(
                        color: isAi ? AppColors.textPrimary : Colors.white,
                        fontSize: 14,
                        fontWeight: isAi ? FontWeight.normal : FontWeight.w600,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Input Bar
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _queryController,
                      decoration: InputDecoration(
                        hintText: "Ask in Marathi, Hindi, English...",
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.mic, color: AppColors.secondaryAmber),
                          onPressed: () => _handleQuery("आजची विक्री किती?"),
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      onSubmitted: _handleQuery,
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    backgroundColor: AppColors.primaryGreen,
                    child: IconButton(
                      icon: const Icon(Icons.send, color: Colors.white, size: 20),
                      onPressed: () => _handleQuery(_queryController.text),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
