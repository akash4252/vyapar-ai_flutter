import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/product_provider.dart';
import '../common/stat_card.dart';
import '../navigation/app_routes.dart';

class InventoryDashboardScreen extends StatelessWidget {
  const InventoryDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = context.watch<ProductProvider>();
    final totalInventoryValue = products.products.fold(0.0, (sum, p) => sum + (p.purchasePrice * p.currentStock));

    return Scaffold(
      appBar: AppBar(
        title: const Text("Inventory / मालसाठा व्यवस्थापन"),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, AppRoutes.addEditProduct),
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Product / वस्तू जोडा"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: StatCard(
                  title: "Total Stock Value",
                  value: CurrencyFormatter.format(totalInventoryValue),
                  subtitle: "At purchase cost",
                  icon: Icons.inventory,
                  iconColor: AppColors.primaryGreen,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: StatCard(
                  title: "Low Stock Items",
                  value: "${products.lowStockProducts.length} Items",
                  subtitle: "Need replenishment",
                  icon: Icons.warning_amber,
                  iconColor: AppColors.error,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text("Inventory Tools", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),

          _buildInventoryTile(
            title: "Product Directory / सर्व वस्तू",
            subtitle: "${products.products.length} registered products",
            icon: Icons.list_alt,
            color: AppColors.primaryGreen,
            onTap: () => Navigator.pushNamed(context, AppRoutes.productList),
          ),
          const SizedBox(height: 8),
          _buildInventoryTile(
            title: "Low Stock Alerts / संपलेला माल",
            subtitle: "${products.lowStockProducts.length} items below minimum threshold",
            icon: Icons.warning_amber,
            color: AppColors.error,
            onTap: () => Navigator.pushNamed(context, AppRoutes.lowStock),
          ),
          const SizedBox(height: 8),
          _buildInventoryTile(
            title: "Stock Adjustment / माल दुरुस्ती",
            subtitle: "Update physical count, damage, expiry",
            icon: Icons.tune,
            color: AppColors.secondaryAmber,
            onTap: () => Navigator.pushNamed(context, AppRoutes.stockAdjustment),
          ),
          const SizedBox(height: 8),
          _buildInventoryTile(
            title: "Smart Purchase Order / AI खरेदी",
            subtitle: "Automatic order generator for distributors",
            icon: Icons.auto_awesome,
            color: AppColors.tertiaryBlue,
            onTap: () => Navigator.pushNamed(context, AppRoutes.smartPo),
          ),
        ],
      ),
    );
  }

  Widget _buildInventoryTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0.8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 24),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
      ),
    );
  }
}
