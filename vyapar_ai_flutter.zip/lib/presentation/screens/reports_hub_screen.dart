import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../navigation/app_routes.dart';

class ReportsHubScreen extends StatelessWidget {
  const ReportsHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Business Reports / रिपोर्ट्स"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildReportTile(
            title: "Sales Analytics / विक्री अहवाल",
            subtitle: "Daily, weekly and monthly sales analysis",
            icon: Icons.trending_up,
            color: AppColors.primaryGreen,
            onTap: () => Navigator.pushNamed(context, AppRoutes.salesReport),
          ),
          const SizedBox(height: 8),
          _buildReportTile(
            title: "Profit & Loss / नफा-तोटा अहवाल",
            subtitle: "Gross profit, expense deduction & net margins",
            icon: Icons.savings,
            color: const Color(0xFF059669),
            onTap: () => Navigator.pushNamed(context, AppRoutes.profitReport),
          ),
          const SizedBox(height: 8),
          _buildReportTile(
            title: "GST Tax Report (GSTR-1)",
            subtitle: "Taxable sales, CGST, SGST, IGST breakdown",
            icon: Icons.receipt_long,
            color: AppColors.tertiaryBlue,
            onTap: () => Navigator.pushNamed(context, AppRoutes.gstReport),
          ),
          const SizedBox(height: 8),
          _buildReportTile(
            title: "Expense Manager / दुकानाचे खर्च",
            subtitle: "Track store rent, electricity, salaries & transport",
            icon: Icons.paid,
            color: AppColors.secondaryDark,
            onTap: () => Navigator.pushNamed(context, AppRoutes.expenseManager),
          ),
        ],
      ),
    );
  }

  Widget _buildReportTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0.8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 24),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
      ),
    );
  }
}
