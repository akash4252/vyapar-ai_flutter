import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/expense.dart';
import '../../data/repositories/supplier_repository.dart';

class ExpenseManagerScreen extends StatefulWidget {
  const ExpenseManagerScreen({super.key});

  @override
  State<ExpenseManagerScreen> createState() => _ExpenseManagerScreenState();
}

class _ExpenseManagerScreenState extends State<ExpenseManagerScreen> {
  final SupplierRepository _repository = SupplierRepository();
  List<Expense> _expenses = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    final list = await _repository.getAllExpenses();
    setState(() {
      _expenses = list;
      _isLoading = false;
    });
  }

  void _showAddExpenseDialog() {
    final amountCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    String category = "RENT";

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text("Record Expense / खर्च नोंदवा"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    value: category,
                    decoration: const InputDecoration(labelText: "Category"),
                    items: const [
                      DropdownMenuItem(value: "RENT", child: Text("Shop Rent / भाडे")),
                      DropdownMenuItem(value: "ELECTRICITY", child: Text("Electricity / वीज बिल")),
                      DropdownMenuItem(value: "SALARY", child: Text("Staff Salary / पगार")),
                      DropdownMenuItem(value: "TRANSPORT", child: Text("Transport / वाहतूक")),
                      DropdownMenuItem(value: "PACKAGING", child: Text("Packaging / पिशव्या")),
                      DropdownMenuItem(value: "OTHER", child: Text("Other / इतर")),
                    ],
                    onChanged: (val) => setDialogState(() => category = val!),
                  ),
                  const SizedBox(height: 10),
                  TextField(controller: amountCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Amount (₹) *")),
                  const SizedBox(height: 10),
                  TextField(controller: descCtrl, decoration: const InputDecoration(labelText: "Description / तपशील")),
                ],
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
                ElevatedButton(
                  onPressed: () async {
                    final amt = double.tryParse(amountCtrl.text);
                    if (amt != null && amt > 0) {
                      final exp = Expense(
                        category: category,
                        amount: amt,
                        description: descCtrl.text.trim().isEmpty ? null : descCtrl.text.trim(),
                      );
                      await _repository.addExpense(exp);
                      Navigator.pop(ctx);
                      _loadExpenses();
                    }
                  },
                  child: const Text("Save"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalExpense = _expenses.fold(0.0, (sum, e) => sum + e.amount);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Store Expenses / दुकानाचे खर्च"),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddExpenseDialog,
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Expense / खर्च नोंदवा"),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  color: AppColors.surfaceVariantLight,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Total Expenses Recorded", style: TextStyle(fontWeight: FontWeight.bold)),
                        Text(CurrencyFormatter.format(totalExpense), style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.error, fontSize: 18)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Expense Log", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),

                if (_expenses.isEmpty) ...[
                  const Center(child: Padding(padding: EdgeInsets.all(24), child: Text("No expenses recorded yet."))),
                ] else ...[
                  ..._expenses.map((e) {
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: AppColors.secondaryContainer,
                          child: Icon(Icons.paid, color: AppColors.secondaryDark),
                        ),
                        title: Text(e.category.replaceAll('_', ' '), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        subtitle: Text("${AppDateUtils.formatDate(e.date)}${e.description != null ? ' • ${e.description}' : ''}"),
                        trailing: Text(
                          CurrencyFormatter.format(e.amount),
                          style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.error, fontSize: 15),
                        ),
                      ),
                    );
                  }),
                ],
              ],
            ),
    );
  }
}
