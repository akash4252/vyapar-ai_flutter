import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/date_utils.dart';
import '../../providers/report_provider.dart';
import '../navigation/app_routes.dart';

class BillHistoryScreen extends StatelessWidget {
  const BillHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reports = context.watch<ReportProvider>();
    final invoices = reports.allInvoices;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Bill History / सर्व बिले"),
      ),
      body: invoices.isEmpty
          ? const Center(
              child: Text("No bills recorded yet.", style: TextStyle(color: AppColors.textSecondary)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: invoices.length,
              itemBuilder: (ctx, i) {
                final item = invoices[i];
                final inv = item.invoice;
                return Card(
                  elevation: 0.8,
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    title: Text(inv.customerName, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("${inv.invoiceNumber} • ${AppDateUtils.formatDateTime(inv.createdAt)}\nMode: ${inv.paymentMode} | ${item.items.length} items"),
                    isThreeLine: true,
                    trailing: Text(
                      CurrencyFormatter.format(inv.grandTotal),
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppColors.primaryGreen),
                    ),
                    onTap: () => Navigator.pushNamed(context, AppRoutes.invoiceSuccess, arguments: inv.invoiceNumber),
                  ),
                );
              },
            ),
    );
  }
}
