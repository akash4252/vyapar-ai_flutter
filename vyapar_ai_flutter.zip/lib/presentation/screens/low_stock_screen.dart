import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/product_provider.dart';
import '../common/product_row.dart';
import '../navigation/app_routes.dart';

class LowStockScreen extends StatelessWidget {
  const LowStockScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = context.watch<ProductProvider>();
    final lowStock = products.lowStockProducts;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Low Stock Alerts / संपलेला माल"),
      ),
      bottomNavigationBar: lowStock.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: SafeArea(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => Navigator.pushNamed(context, AppRoutes.smartPo),
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text("GENERATE PURCHASE ORDER / PO बनवा", style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ),
      body: lowStock.isEmpty
          ? const Center(
              child: Text("All stocks are healthy! No low stock items.", style: TextStyle(color: AppColors.textSecondary)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: lowStock.length,
              itemBuilder: (ctx, i) {
                final p = lowStock[i];
                return ProductRow(
                  product: p,
                  onTap: () => Navigator.pushNamed(context, AppRoutes.addEditProduct, arguments: p),
                );
              },
            ),
    );
  }
}
