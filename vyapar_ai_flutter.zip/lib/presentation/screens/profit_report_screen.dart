import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/report_provider.dart';

class ProfitReportScreen extends StatelessWidget {
  const ProfitReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reports = context.watch<ReportProvider>();

    final gross = reports.todayGrossProfit;
    final expenses = reports.todayExpenses;
    final netProfit = reports.todayNetProfit;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Profit & Loss / नफा-तोटा अहवाल"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: netProfit >= 0 ? AppColors.primaryGreen : AppColors.error,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text("TODAY'S NET REALIZED PROFIT", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                  const SizedBox(height: 6),
                  Text(
                    CurrencyFormatter.format(netProfit),
                    style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  const Text("Gross Margin minus Store Operating Expenses", style: TextStyle(color: Colors.white70, fontSize: 11)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _pRow("Total Sales Revenue (+)", CurrencyFormatter.format(reports.todaySales), Colors.black87),
                  const SizedBox(height: 10),
                  _pRow("Gross Margin (avg ~20%)", CurrencyFormatter.format(gross), AppColors.primaryGreen),
                  const SizedBox(height: 10),
                  _pRow("Operating Expenses (-)", "-${CurrencyFormatter.format(expenses)}", AppColors.error),
                  const Divider(height: 24),
                  _pRow("Net Profit", CurrencyFormatter.format(netProfit), netProfit >= 0 ? AppColors.primaryGreen : AppColors.error, isBold: true),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _pRow(String label, String val, Color color, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 15 : 13)),
        Text(val, style: TextStyle(fontWeight: isBold ? FontWeight.w900 : FontWeight.bold, color: color, fontSize: isBold ? 16 : 14)),
      ],
    );
  }
}
