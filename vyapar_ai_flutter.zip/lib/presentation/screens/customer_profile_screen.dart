import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/customer.dart';
import '../../data/repositories/khata_repository.dart';
import '../../providers/khata_provider.dart';
import '../../providers/settings_provider.dart';
import '../common/custom_buttons.dart';
import '../navigation/app_routes.dart';

class CustomerProfileScreen extends StatefulWidget {
  final Customer customer;

  const CustomerProfileScreen({super.key, required this.customer});

  @override
  State<CustomerProfileScreen> createState() => _CustomerProfileScreenState();
}

class _CustomerProfileScreenState extends State<CustomerProfileScreen> {
  List<CustomerTransaction> _transactions = [];
  bool _isLoading = true;
  late Customer _customer;

  @override
  void initState() {
    super.initState();
    _customer = widget.customer;
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final repo = KhataRepository();
    final list = await repo.getCustomerTransactions(_customer.id!);
    final updatedCust = await repo.getCustomerById(_customer.id!);
    setState(() {
      _transactions = list;
      if (updatedCust != null) _customer = updatedCust;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final khataProvider = context.read<KhataProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(_customer.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            tooltip: "Send WhatsApp Reminder",
            onPressed: () {
              khataProvider.sendWhatsAppReminder(_customer, settings.businessInfo?.name ?? "Shree Ganesh General Store");
            },
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: SafeArea(
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.error,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () async {
                    await Navigator.pushNamed(context, AppRoutes.addKhataEntry, arguments: {
                      'customer': _customer,
                      'type': 'CREDIT_GIVEN',
                    });
                    _loadHistory();
                  },
                  icon: const Icon(Icons.arrow_upward),
                  label: const Text("GAVE CREDIT / दिले"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () async {
                    await Navigator.pushNamed(context, AppRoutes.addKhataEntry, arguments: {
                      'customer': _customer,
                      'type': 'PAYMENT_RECEIVED',
                    });
                    _loadHistory();
                  },
                  icon: const Icon(Icons.arrow_downward),
                  label: const Text("GOT PAYMENT / मिळाले"),
                ),
              ),
            ],
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Balance Summary Card
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: _customer.currentCreditBalance > 0 ? AppColors.error : AppColors.primaryGreen,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text("CURRENT BALANCE DUE / बाकी रक्कम", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                  const SizedBox(height: 6),
                  Text(
                    CurrencyFormatter.format(_customer.currentCreditBalance),
                    style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Mobile: ${_customer.mobile ?? 'None'} | Loyalty: ${_customer.loyaltyPoints} pts",
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),
          const Text("Transaction Ledger / जमा-नावे हिशोब", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          if (_isLoading) ...[
            const Center(child: CircularProgressIndicator()),
          ] else if (_transactions.isEmpty) ...[
            const Center(child: Padding(padding: EdgeInsets.all(24), child: Text("No transactions recorded yet."))),
          ] else ...[
            ..._transactions.map((tx) {
              final isCredit = tx.transactionType == "CREDIT_GIVEN";
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isCredit ? AppColors.error.withOpacity(0.12) : AppColors.primaryGreen.withOpacity(0.12),
                    child: Icon(isCredit ? Icons.arrow_upward : Icons.arrow_downward, color: isCredit ? AppColors.error : AppColors.primaryGreen),
                  ),
                  title: Text(isCredit ? "Credit Given (Udhaar)" : "Payment Received (Jama)", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  subtitle: Text("${AppDateUtils.formatDateTime(tx.createdAt)}${tx.note != null ? ' • ${tx.note}' : ''}"),
                  trailing: Text(
                    CurrencyFormatter.format(tx.amount),
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: isCredit ? AppColors.error : AppColors.primaryGreen),
                  ),
                ),
              );
            }),
          ],
          const SizedBox(height: 60),
        ],
      ),
    );
  }
}
