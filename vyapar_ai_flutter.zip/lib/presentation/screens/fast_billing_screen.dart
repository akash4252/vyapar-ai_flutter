import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/voice/voice_parser_engine.dart';
import '../../providers/billing_provider.dart';
import '../../providers/product_provider.dart';
import '../../providers/khata_provider.dart';
import '../common/cart_item_row.dart';
import '../common/product_row.dart';
import '../common/voice_confirmation_sheet.dart';
import '../navigation/app_routes.dart';

class FastBillingScreen extends StatefulWidget {
  const FastBillingScreen({super.key});

  @override
  State<FastBillingScreen> createState() => _FastBillingScreenState();
}

class _FastBillingScreenState extends State<FastBillingScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _showProductCatalog = false;

  void _triggerVoiceInput() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return VoiceConfirmationSheet(
          spokenText: "साखर दोन किलो आणि दूध तीन पाकीट",
          parsedResult: VoiceParserEngine.parse("Sugar 2kg and milk 3 packets"),
          onConfirm: () {
            final billing = context.read<BillingProvider>();
            final products = context.read<ProductProvider>().products;

            final sugar = products.firstWhere((p) => p.name.contains("Sugar"), orElse: () => products.first);
            final milk = products.firstWhere((p) => p.name.contains("Milk"), orElse: () => products.first);

            billing.addToCart(sugar, quantity: 2);
            billing.addToCart(milk, quantity: 3);

            Navigator.pop(ctx);
          },
          onCancel: () => Navigator.pop(ctx),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final billing = context.watch<BillingProvider>();
    final productProvider = context.watch<ProductProvider>();
    final khataProvider = context.watch<KhataProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Fast POS Billing / जलद बिलिंग", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            tooltip: "Scan Barcode",
            onPressed: () => Navigator.pushNamed(context, AppRoutes.barcodeScanner),
          ),
          IconButton(
            icon: const Icon(Icons.mic),
            tooltip: "Voice Bill",
            onPressed: _triggerVoiceInput,
          ),
          if (billing.cartItems.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              tooltip: "Clear Cart",
              onPressed: () => billing.clearCart(),
            ),
        ],
      ),
      bottomNavigationBar: billing.cartItems.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -4)),
                ],
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${billing.totalItemCount} Items",
                              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              CurrencyFormatter.format(billing.grandTotal),
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.primaryGreen),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 48,
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primaryGreen,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: () => Navigator.pushNamed(context, AppRoutes.paymentCheckout),
                            icon: const Icon(Icons.arrow_forward),
                            label: const Text("CHECKOUT / बिल बनवा", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
      body: Column(
        children: [
          // Customer Selection Strip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: AppColors.surfaceVariantLight,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.person_outline, size: 20, color: AppColors.textSecondary),
                    const SizedBox(width: 8),
                    Text(
                      billing.selectedCustomer?.name ?? "Walk-in Customer / सामान्य ग्राहक",
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ],
                ),
                TextButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (ctx) {
                        return SimpleDialog(
                          title: const Text("Select Customer"),
                          children: [
                            SimpleDialogOption(
                              onPressed: () {
                                billing.selectCustomer(null);
                                Navigator.pop(ctx);
                              },
                              child: const Text("Walk-in Customer (No Khata)"),
                            ),
                            ...khataProvider.customers.map((c) {
                              return SimpleDialogOption(
                                onPressed: () {
                                  billing.selectCustomer(c);
                                  Navigator.pop(ctx);
                                },
                                child: Text("${c.name} (${CurrencyFormatter.format(c.currentCreditBalance)})"),
                              );
                            }),
                          ],
                        );
                      },
                    );
                  },
                  child: const Text("Change / बदला"),
                ),
              ],
            ),
          ),

          // Search Bar
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Search products (Maggi, Sugar, Oil...) / शोधा",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _showProductCatalog = false);
                        },
                      )
                    : null,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
              onChanged: (val) {
                setState(() {
                  _showProductCatalog = val.trim().isNotEmpty;
                });
              },
            ),
          ),

          // Catalog or Cart View
          Expanded(
            child: _showProductCatalog
                ? ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: productProvider.products.where((p) {
                      final q = _searchController.text.toLowerCase();
                      return p.name.toLowerCase().contains(q) ||
                          (p.localName?.toLowerCase().contains(q) ?? false) ||
                          p.aliases.any((a) => a.toLowerCase().contains(q));
                    }).length,
                    itemBuilder: (ctx, i) {
                      final filtered = productProvider.products.where((p) {
                        final q = _searchController.text.toLowerCase();
                        return p.name.toLowerCase().contains(q) ||
                            (p.localName?.toLowerCase().contains(q) ?? false) ||
                            p.aliases.any((a) => a.toLowerCase().contains(q));
                      }).toList();
                      final prod = filtered[i];
                      return ProductRow(
                        product: prod,
                        onAddToCart: () {
                          billing.addToCart(prod);
                          _searchController.clear();
                          setState(() => _showProductCatalog = false);
                        },
                      );
                    },
                  )
                : billing.cartItems.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: AppColors.primaryGreen.withOpacity(0.08),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.add_shopping_cart, size: 54, color: AppColors.primaryGreen),
                            ),
                            const SizedBox(height: 16),
                            const Text("Cart is empty", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            const SizedBox(height: 4),
                            const Text(
                              "Speak (मॅगी दोन), scan barcode, or search above",
                              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.secondaryAmber,
                              ),
                              onPressed: _triggerVoiceInput,
                              icon: const Icon(Icons.mic),
                              label: const Text("TRY VOICE BILLING / बोलून बिल"),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: billing.cartItems.length,
                        itemBuilder: (ctx, idx) {
                          final item = billing.cartItems[idx];
                          return CartItemRow(
                            item: item,
                            onQuantityChanged: (q) => billing.updateQuantity(idx, q),
                            onRemove: () => billing.removeFromCart(idx),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
