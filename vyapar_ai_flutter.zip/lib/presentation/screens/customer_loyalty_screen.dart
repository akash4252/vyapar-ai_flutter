import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/khata_provider.dart';
import '../common/stat_card.dart';

class CustomerLoyaltyScreen extends StatelessWidget {
  const CustomerLoyaltyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final khata = context.watch<KhataProvider>();
    final customers = khata.customers;
    final totalPoints = customers.fold(0, (sum, c) => sum + c.loyaltyPoints);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Customer Loyalty / लॉयल्टी रिवॉर्ड्स"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: AppColors.secondaryAmber.withOpacity(0.15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.stars, color: AppColors.secondaryDark, size: 36),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Active Loyalty Rules", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF78350F))),
                        Text("1 Point earned per ₹100 spent.\n100 Points = ₹50 bill discount.", style: TextStyle(fontSize: 12, color: Color(0xFF92400E))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          StatCard(
            title: "Total Active Points Issued",
            value: "$totalPoints Points",
            subtitle: "Equivalent to ${CurrencyFormatter.format(totalPoints * 0.5)} store discounts",
            icon: Icons.card_giftcard,
            iconColor: AppColors.secondaryAmber,
          ),
          const SizedBox(height: 20),
          const Text("Customer Points Leaderboard", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          ...customers.map((c) {
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("Total Spent: ${CurrencyFormatter.format(c.totalSpent)}"),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text("${c.loyaltyPoints} Pts", style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.primaryGreen, fontSize: 16)),
                    Text("Worth ${CurrencyFormatter.format(c.loyaltyPoints * 0.5)}", style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
