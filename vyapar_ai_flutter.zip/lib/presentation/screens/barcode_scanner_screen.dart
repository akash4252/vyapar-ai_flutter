import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/billing_provider.dart';
import '../../providers/product_provider.dart';
import '../navigation/app_routes.dart';

class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  final TextEditingController _manualBarcodeController = TextEditingController();

  void _handleBarcodeScanned(String barcode) async {
    final productProvider = context.read<ProductProvider>();
    final billingProvider = context.read<BillingProvider>();

    final product = await productProvider.findProductByBarcode(barcode);
    if (product != null) {
      billingProvider.addToCart(product);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Added: ${product.name} (₹${product.sellingPrice})"),
            backgroundColor: AppColors.primaryGreen,
            duration: const Duration(seconds: 2),
          ),
        );
        Navigator.pop(context);
      }
    } else {
      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text("Product Not Found"),
            content: Text("No item registered with barcode: $barcode.\nWould you like to register it now?"),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, AppRoutes.addEditProduct, arguments: barcode);
                },
                child: const Text("Add Product"),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Barcode Scanner / स्कॅनर"),
      ),
      body: Column(
        children: [
          // Viewfinder Camera Box
          Expanded(
            child: Container(
              color: Colors.black87,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 260,
                    height: 260,
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.primaryGreen, width: 3),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.qr_code_scanner, size: 64, color: AppColors.primaryGreen),
                        SizedBox(height: 12),
                        Text(
                          "Point camera at product barcode",
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Quick Scan Simulated Barcodes (for Emulators & Quick Testing)
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Quick Test Barcodes / चाचणी बारकोड:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    ActionChip(
                      label: const Text("Maggi 70g"),
                      onPressed: () => _handleBarcodeScanned("8901058852391"),
                    ),
                    ActionChip(
                      label: const Text("Madhur Sugar"),
                      onPressed: () => _handleBarcodeScanned("8906007280017"),
                    ),
                    ActionChip(
                      label: const Text("Amul Milk"),
                      onPressed: () => _handleBarcodeScanned("8901262010051"),
                    ),
                    ActionChip(
                      label: const Text("Fortune Oil"),
                      onPressed: () => _handleBarcodeScanned("8906007281052"),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _manualBarcodeController,
                        decoration: const InputDecoration(
                          hintText: "Enter barcode manually...",
                          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryGreen),
                      onPressed: () {
                        if (_manualBarcodeController.text.isNotEmpty) {
                          _handleBarcodeScanned(_manualBarcodeController.text.trim());
                        }
                      },
                      child: const Text("LOOKUP"),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
