import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../data/models/supplier.dart';
import '../../data/repositories/supplier_repository.dart';
import '../navigation/app_routes.dart';

class SupplierListScreen extends StatefulWidget {
  const SupplierListScreen({super.key});

  @override
  State<SupplierListScreen> createState() => _SupplierListScreenState();
}

class _SupplierListScreenState extends State<SupplierListScreen> {
  final SupplierRepository _repository = SupplierRepository();
  List<Supplier> _suppliers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSuppliers();
  }

  Future<void> _loadSuppliers() async {
    final list = await _repository.getAllSuppliers();
    setState(() {
      _suppliers = list;
      _isLoading = false;
    });
  }

  void _showAddSupplierDialog() {
    final nameCtrl = TextEditingController();
    final companyCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final gstinCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text("Add Supplier / सप्लायर जोडा"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: "Contact Person *")),
              const SizedBox(height: 8),
              TextField(controller: companyCtrl, decoration: const InputDecoration(labelText: "Company / Distributor Name")),
              const SizedBox(height: 8),
              TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Mobile Number")),
              const SizedBox(height: 8),
              TextField(controller: gstinCtrl, decoration: const InputDecoration(labelText: "GSTIN")),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
            ElevatedButton(
              onPressed: () async {
                if (nameCtrl.text.trim().isNotEmpty) {
                  final s = Supplier(
                    name: nameCtrl.text.trim(),
                    companyName: companyCtrl.text.trim().isEmpty ? null : companyCtrl.text.trim(),
                    mobile: phoneCtrl.text.trim().isEmpty ? null : phoneCtrl.text.trim(),
                    gstin: gstinCtrl.text.trim().isEmpty ? null : gstinCtrl.text.trim(),
                  );
                  await _repository.insertSupplier(s);
                  Navigator.pop(ctx);
                  _loadSuppliers();
                }
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Suppliers & Purchases / सप्लायर"),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_shopping_cart),
            tooltip: "New Purchase",
            onPressed: () async {
              await Navigator.pushNamed(context, AppRoutes.newPurchase);
              _loadSuppliers();
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddSupplierDialog,
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Supplier"),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _suppliers.isEmpty
              ? const Center(child: Text("No suppliers registered yet."))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _suppliers.length,
                  itemBuilder: (ctx, i) {
                    final s = _suppliers[i];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: AppColors.primaryContainer,
                          child: Icon(Icons.local_shipping, color: AppColors.primaryGreen),
                        ),
                        title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text("${s.companyName ?? ''}\nPhone: ${s.mobile ?? 'None'} | GST: ${s.gstin ?? 'Unregistered'}"),
                        isThreeLine: true,
                        trailing: s.currentOutstanding > 0
                            ? Text(
                                CurrencyFormatter.format(s.currentOutstanding),
                                style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.error, fontSize: 14),
                              )
                            : null,
                      ),
                    );
                  },
                ),
    );
  }
}
