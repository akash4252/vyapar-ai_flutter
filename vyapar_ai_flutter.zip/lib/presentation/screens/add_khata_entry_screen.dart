import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/customer.dart';
import '../../providers/khata_provider.dart';
import '../common/custom_buttons.dart';

class AddKhataEntryScreen extends StatefulWidget {
  final Map<String, dynamic> arguments;

  const AddKhataEntryScreen({super.key, required this.arguments});

  @override
  State<AddKhataEntryScreen> createState() => _AddKhataEntryScreenState();
}

class _AddKhataEntryScreenState extends State<AddKhataEntryScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  late Customer _customer;
  late String _type; // CREDIT_GIVEN or PAYMENT_RECEIVED

  @override
  void initState() {
    super.initState();
    _customer = widget.arguments['customer'] as Customer;
    _type = widget.arguments['type'] as String;
  }

  @override
  Widget build(BuildContext context) {
    final isCredit = _type == 'CREDIT_GIVEN';

    return Scaffold(
      appBar: AppBar(
        title: Text(isCredit ? "Give Credit / उधार दिले" : "Got Payment / पैसे मिळाले"),
        backgroundColor: isCredit ? AppColors.error : AppColors.primaryGreen,
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: isCredit ? "SAVE CREDIT / उधार नोंदवा" : "SAVE PAYMENT / जमा नोंदवा",
            color: isCredit ? AppColors.error : AppColors.primaryGreen,
            onClick: () async {
              final amt = double.tryParse(_amountController.text);
              if (amt != null && amt > 0) {
                await context.read<KhataProvider>().addKhataTransaction(
                  customerId: _customer.id!,
                  type: _type,
                  amount: amt,
                  note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
                );
                if (mounted) Navigator.pop(context);
              }
            },
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text("Customer: ${_customer.name}", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 16),
          TextField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            autofocus: true,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            decoration: InputDecoration(
              prefixText: "₹ ",
              prefixStyle: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              labelText: "Amount (रक्कम) *",
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _noteController,
            decoration: InputDecoration(
              labelText: "Note / तपशील (उदा. राशन बिल, रोख मिळाले)",
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ],
      ),
    );
  }
}
