import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/settings_provider.dart';

class LanguageSettingsScreen extends StatelessWidget {
  const LanguageSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final currentLang = settings.language;

    final languages = [
      {'code': 'EN', 'name': 'English', 'native': 'English (India)'},
      {'code': 'MR', 'name': 'Marathi', 'native': 'मराठी'},
      {'code': 'HI', 'name': 'Hindi', 'native': 'हिन्दी'},
      {'code': 'GU', 'name': 'Gujarati', 'native': 'ગુજરાતી (Coming soon)'},
      {'code': 'KN', 'name': 'Kannada', 'native': 'ಕನ್ನಡ (Coming soon)'},
      {'code': 'TA', 'name': 'Tamil', 'native': 'தமிழ் (Coming soon)'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Language Settings / भाषा निवडा"),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: languages.length,
        itemBuilder: (ctx, i) {
          final lang = languages[i];
          final isSelected = lang['code'] == currentLang;

          return Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: isSelected ? AppColors.primaryGreen : Colors.transparent, width: 2),
            ),
            child: ListTile(
              title: Text(lang['native']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              subtitle: Text(lang['name']!),
              trailing: isSelected ? const Icon(Icons.check_circle, color: AppColors.primaryGreen) : null,
              onTap: () {
                if (['EN', 'MR', 'HI'].contains(lang['code'])) {
                  context.read<SettingsProvider>().setLanguage(lang['code']!);
                }
              },
            ),
          );
        },
      ),
    );
  }
}
