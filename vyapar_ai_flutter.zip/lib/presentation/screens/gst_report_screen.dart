import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/report_provider.dart';
import '../common/stat_card.dart';

class GstReportScreen extends StatelessWidget {
  const GstReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reports = context.watch<ReportProvider>();
    final invoices = reports.allInvoices;

    final totalTaxable = invoices.fold(0.0, (sum, i) => sum + i.invoice.subtotal);
    final totalCgst = invoices.fold(0.0, (sum, i) => sum + i.invoice.cgst);
    final totalSgst = invoices.fold(0.0, (sum, i) => sum + i.invoice.sgst);
    final totalIgst = invoices.fold(0.0, (sum, i) => sum + i.invoice.igst);
    final totalGst = totalCgst + totalSgst + totalIgst;

    return Scaffold(
      appBar: AppBar(
        title: const Text("GST Tax Report (GSTR-1)"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          StatCard(
            title: "Total GST Tax Liability",
            value: CurrencyFormatter.format(totalGst),
            subtitle = "Collected on ${invoices.length} invoices",
            icon: Icons.receipt_long,
            iconColor: AppColors.tertiaryBlue,
          ),
          const SizedBox(height: 16),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _gstRow("Total Taxable Value", CurrencyFormatter.format(totalTaxable)),
                  const SizedBox(height: 10),
                  _gstRow("Central GST (CGST)", CurrencyFormatter.format(totalCgst)),
                  const SizedBox(height: 10),
                  _gstRow("State GST (SGST)", CurrencyFormatter.format(totalSgst)),
                  const SizedBox(height: 10),
                  _gstRow("Integrated GST (IGST)", CurrencyFormatter.format(totalIgst)),
                  const Divider(height: 24),
                  _gstRow("Total GST Payable", CurrencyFormatter.format(totalGst), isBold: true),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _gstRow(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 15 : 13)),
        Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.w900 : FontWeight.bold, fontSize: isBold ? 16 : 14, color: isBold ? AppColors.primaryGreen : Colors.black87)),
      ],
    );
  }
}
