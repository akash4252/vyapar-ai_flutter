import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/date_utils.dart';
import '../../core/printer/invoice_pdf_generator.dart';
import '../../data/models/invoice.dart';
import '../../data/repositories/invoice_repository.dart';
import '../../providers/settings_provider.dart';
import '../common/custom_buttons.dart';
import '../navigation/app_routes.dart';

class InvoiceSuccessScreen extends StatefulWidget {
  final String invoiceNumber;

  const InvoiceSuccessScreen({super.key, required this.invoiceNumber});

  @override
  State<InvoiceSuccessScreen> createState() => _InvoiceSuccessScreenState();
}

class _InvoiceSuccessScreenState extends State<InvoiceSuccessScreen> {
  InvoiceWithItems? _invoiceWithItems;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInvoice();
  }

  Future<void> _loadInvoice() async {
    final repo = InvoiceRepository();
    final data = await repo.getInvoiceByNumber(widget.invoiceNumber);
    setState(() {
      _invoiceWithItems = data;
      _isLoading = false;
    });
  }

  Future<void> _printPdfInvoice() async {
    if (_invoiceWithItems == null) return;
    final settings = context.read<SettingsProvider>();
    final biz = settings.businessInfo;
    final inv = _invoiceWithItems!.invoice;
    final items = _invoiceWithItems!.items;

    final pdfBytes = await InvoicePdfGenerator.generateGstInvoicePdf(
      businessName: biz?.name ?? "Shree Ganesh General Store",
      address: biz?.address ?? "Shop No. 4, MG Road, Pune",
      mobile: biz?.mobile,
      gstin: biz?.gstin,
      invoiceNumber: inv.invoiceNumber,
      date: AppDateUtils.formatDate(inv.createdAt),
      customerName: inv.customerName,
      customerPhone: inv.customerMobile,
      items: items.map((i) => {
        'name': i.productName,
        'qty': i.quantity,
        'unit': i.unit,
        'price': i.unitPrice,
        'gstRate': i.gstRate,
        'total': i.totalAmount,
      }).toList(),
      subtotal: inv.subtotal,
      discount: inv.discountAmount,
      cgst: inv.cgst,
      sgst: inv.sgst,
      igst: inv.igst,
      grandTotal: inv.grandTotal,
      paymentMode: inv.paymentMode,
    );

    await Printing.layoutPdf(onLayout: (format) async => pdfBytes);
  }

  Future<void> _shareOnWhatsApp() async {
    if (_invoiceWithItems == null) return;
    final settings = context.read<SettingsProvider>();
    final biz = settings.businessInfo;
    final inv = _invoiceWithItems!.invoice;

    final phone = (inv.customerMobile ?? "").replaceAll(RegExp(r'[^0-9]'), '');
    final fullPhone = phone.length == 10 ? "91$phone" : phone;

    final text = "Namaste ${inv.customerName} ji! Thank you for shopping with *${biz?.name ?? 'our store'}*.\n\n*Invoice No:* ${inv.invoiceNumber}\n*Total Amount:* ${CurrencyFormatter.format(inv.grandTotal)}\n*Payment Mode:* ${inv.paymentMode}\n\nHave a wonderful day!";
    final uri = Uri.parse("https://api.whatsapp.com/send?phone=$fullPhone&text=${Uri.encodeComponent(text)}");

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final inv = _invoiceWithItems?.invoice;
    final items = _invoiceWithItems?.items ?? [];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Invoice Created / बिल तयार झाले"),
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () => Navigator.pushReplacementNamed(context, AppRoutes.dashboard),
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -4))],
        ),
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: "CREATE NEW BILL / नवीन बिल बनवा",
            onClick: () => Navigator.pushReplacementNamed(context, AppRoutes.fastBilling),
            icon: Icons.add_shopping_cart,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Celebration Icon Header
          Center(
            child: Column(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: const BoxDecoration(color: AppColors.primaryContainer, shape: BoxShape.circle),
                  child: const Icon(Icons.check_circle, color: AppColors.primaryGreen, size: 48),
                ),
                const SizedBox(height: 12),
                const Text("Payment Successful! / बिल यशस्वी", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                Text(
                  inv?.invoiceNumber ?? widget.invoiceNumber,
                  style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 6),
                Text(
                  CurrencyFormatter.format(inv?.grandTotal ?? 0.0),
                  style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.primaryGreen),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Action Buttons: Print PDF & Share WhatsApp
          Row(
            children: [
              Expanded(
                child: VyaparSecondaryButton(
                  text: "Print / PDF",
                  icon: Icons.print,
                  onClick: _printPdfInvoice,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF25D366),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: _shareOnWhatsApp,
                  icon: const Icon(Icons.share, size: 20),
                  label: const Text("WhatsApp", style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Items summary
          const Text("Billed Items", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                children: [
                  ...items.map((i) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(i.productName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Text("${i.quantity.toStringAsFixed(0)} ${i.unit} @ ₹${i.unitPrice}", style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            ],
                          ),
                          Text(CurrencyFormatter.format(i.totalAmount), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        ],
                      ),
                    );
                  }),
                  const Divider(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Grand Total", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      Text(CurrencyFormatter.format(inv?.grandTotal ?? 0.0), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppColors.primaryGreen)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
