import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../common/custom_buttons.dart';

class BackupRestoreScreen extends StatefulWidget {
  const BackupRestoreScreen({super.key});

  @override
  State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  String? _statusMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Backup & Restore / डेटा बॅकअप"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryContainer,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.security, color: AppColors.onPrimaryContainer),
                    SizedBox(width: 8),
                    Text("100% Offline SQLite Storage", style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.onPrimaryContainer)),
                  ],
                ),
                SizedBox(height: 6),
                Text(
                  "All your bills, customer Khata records, and products are stored securely on your local device without requiring an active internet connection.",
                  style: TextStyle(fontSize: 12, color: AppColors.onPrimaryContainer),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text("Manual Backup Actions", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),

          VyaparPrimaryButton(
            text: "CREATE DATABASE BACKUP NOW",
            icon: Icons.backup,
            onClick: () {
              setState(() {
                _statusMessage = "Backup created successfully: vyapar_ai_backup_${DateTime.now().millisecondsSinceEpoch}.db";
              });
            },
          ),
          const SizedBox(height: 12),
          VyaparSecondaryButton(
            text: "RESTORE FROM BACKUP",
            icon: Icons.restore,
            onClick: () {
              setState(() {
                _statusMessage = "Database snapshot restored successfully!";
              });
            },
          ),

          if (_statusMessage != null) ...[
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariantLight,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.primaryGreen),
              ),
              child: Text(
                _statusMessage!,
                style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
