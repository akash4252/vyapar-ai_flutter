import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/product.dart';
import '../../providers/product_provider.dart';
import '../common/custom_buttons.dart';

class AddEditProductScreen extends StatefulWidget {
  final dynamic argument; // Can be Product (for edit) or String (scanned barcode)

  const AddEditProductScreen({super.key, this.argument});

  @override
  State<AddEditProductScreen> createState() => _AddEditProductScreenState();
}

class _AddEditProductScreenState extends State<AddEditProductScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;
  late TextEditingController _localNameController;
  late TextEditingController _barcodeController;
  late TextEditingController _purchasePriceController;
  late TextEditingController _sellingPriceController;
  late TextEditingController _mrpController;
  late TextEditingController _stockController;
  late TextEditingController _minStockController;
  late TextEditingController _aliasesController;

  String _unit = "pcs";
  double _gstRate = 0.0;
  bool _isEdit = false;
  Product? _existingProduct;

  @override
  void initState() {
    super.initState();
    if (widget.argument is Product) {
      _existingProduct = widget.argument as Product;
      _isEdit = true;
    }

    _nameController = TextEditingController(text: _existingProduct?.name ?? "");
    _localNameController = TextEditingController(text: _existingProduct?.localName ?? "");
    _barcodeController = TextEditingController(
      text: _existingProduct?.barcode ?? (widget.argument is String ? widget.argument as String : ""),
    );
    _purchasePriceController = TextEditingController(text: _existingProduct?.purchasePrice.toString() ?? "");
    _sellingPriceController = TextEditingController(text: _existingProduct?.sellingPrice.toString() ?? "");
    _mrpController = TextEditingController(text: _existingProduct?.mrp.toString() ?? "");
    _stockController = TextEditingController(text: _existingProduct?.currentStock.toString() ?? "0");
    _minStockController = TextEditingController(text: _existingProduct?.minimumStock.toString() ?? "5");
    _aliasesController = TextEditingController(text: _existingProduct?.aliases.join(", ") ?? "");

    _unit = _existingProduct?.unit ?? "pcs";
    _gstRate = _existingProduct?.gstRate ?? 0.0;
  }

  void _saveProduct() async {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text.trim();
      final localName = _localNameController.text.trim().isEmpty ? null : _localNameController.text.trim();
      final barcode = _barcodeController.text.trim().isEmpty ? null : _barcodeController.text.trim();
      final purchasePrice = double.tryParse(_purchasePriceController.text) ?? 0.0;
      final sellingPrice = double.tryParse(_sellingPriceController.text) ?? 0.0;
      final mrp = double.tryParse(_mrpController.text) ?? sellingPrice;
      final stock = double.tryParse(_stockController.text) ?? 0.0;
      final minStock = double.tryParse(_minStockController.text) ?? 5.0;
      final aliases = _aliasesController.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();

      final product = Product(
        id: _existingProduct?.id,
        name: name,
        localName: localName,
        barcode: barcode,
        purchasePrice: purchasePrice,
        sellingPrice: sellingPrice,
        mrp: mrp,
        currentStock: stock,
        minimumStock: minStock,
        unit: _unit,
        gstRate: _gstRate,
        aliases: aliases,
      );

      final provider = context.read<ProductProvider>();
      if (_isEdit) {
        await provider.updateProduct(product);
      } else {
        await provider.addProduct(product);
      }

      if (mounted) {
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEdit ? "Edit Product / वस्तू बदला" : "Add Product / नवीन वस्तू"),
        actions: [
          if (_isEdit)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final provider = context.read<ProductProvider>();
                await provider.deleteProduct(_existingProduct!.id!);
                if (mounted) Navigator.pop(context);
              },
            ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -4))]),
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: _isEdit ? "UPDATE PRODUCT / सेव्ह करा" : "SAVE PRODUCT / वस्तू जोडा",
            onClick: _saveProduct,
            icon: Icons.save,
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: "Product Name (English) *"),
              validator: (v) => v == null || v.trim().isEmpty ? "Required" : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _localNameController,
              decoration: const InputDecoration(labelText: "Local Name / स्थानिक नाव (मॅगी, साखर...)"),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _barcodeController,
              decoration: const InputDecoration(labelText: "Barcode (Optional)", suffixIcon: Icon(Icons.qr_code)),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _purchasePriceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Purchase Price (₹) *"),
                    validator: (v) => v == null || double.tryParse(v) == null ? "Invalid" : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _sellingPriceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Selling Price (₹) *"),
                    validator: (v) => v == null || double.tryParse(v) == null ? "Invalid" : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _stockController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Opening Stock *"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _unit,
                    decoration: const InputDecoration(labelText: "Unit / एकक"),
                    items: ["pcs", "kg", "gm", "ltr", "ml", "pkt", "box", "dozen"].map((u) {
                      return DropdownMenuItem(value: u, child: Text(u));
                    }).toList(),
                    onChanged: (val) => setState(() => _unit = val!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _minStockController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Low Stock Alert Level"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<double>(
                    value: _gstRate,
                    decoration: const InputDecoration(labelText: "GST Rate (%)"),
                    items: [0.0, 5.0, 12.0, 18.0, 28.0].map((rate) {
                      return DropdownMenuItem(value: rate, child: Text("${rate.toInt()}%"));
                    }).toList(),
                    onChanged: (val) => setState(() => _gstRate = val!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _aliasesController,
              decoration: const InputDecoration(
                labelText: "Voice Aliases (Comma separated)",
                helperText: "e.g. Maggi, Maggie, मैगी, मॅगी, नूडल्स",
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
