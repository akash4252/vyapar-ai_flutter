import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../providers/billing_provider.dart';
import '../../providers/settings_provider.dart';
import '../common/custom_buttons.dart';
import '../common/upi_qr_dialog.dart';
import '../navigation/app_routes.dart';

class PaymentCheckoutScreen extends StatefulWidget {
  const PaymentCheckoutScreen({super.key});

  @override
  State<PaymentCheckoutScreen> createState() => _PaymentCheckoutScreenState();
}

class _PaymentCheckoutScreenState extends State<PaymentCheckoutScreen> {
  String _selectedMode = "CASH";
  double _discount = 0.0;
  final TextEditingController _discountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final billing = context.watch<BillingProvider>();
    final settings = context.watch<SettingsProvider>();
    final biz = settings.businessInfo;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Payment & Checkout / पेमेंट"),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -4))],
        ),
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: "COLLECT ${CurrencyFormatter.format(billing.grandTotal)} (${_selectedMode})",
            isLoading: billing.isProcessing,
            onClick: () async {
              if (_selectedMode == "UPI") {
                showDialog(
                  context: context,
                  builder: (ctx) => UpiQrDialog(
                    amount: billing.grandTotal,
                    upiId: biz?.upiId ?? "shreeganesh@upi",
                    businessName: biz?.name ?? "Shree Ganesh Store",
                    onPaymentReceived: () async {
                      billing.setPaymentMode("UPI");
                      final invNum = await billing.checkout();
                      if (mounted && invNum != null) {
                        Navigator.pushReplacementNamed(context, AppRoutes.invoiceSuccess, arguments: invNum);
                      }
                    },
                  ),
                );
              } else {
                billing.setPaymentMode(_selectedMode);
                final invNum = await billing.checkout();
                if (mounted && invNum != null) {
                  Navigator.pushReplacementNamed(context, AppRoutes.invoiceSuccess, arguments: invNum);
                }
              }
            },
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Amount Due Hero Card
          Card(
            shape: RoundedCornerShape(16),
            color: AppColors.primaryGreen,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  const Text("TOTAL AMOUNT DUE / एकूण रक्कम", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Text(
                    CurrencyFormatter.format(billing.grandTotal),
                    style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "${billing.totalItemCount} Items | Billed to: ${billing.selectedCustomer?.name ?? 'Walk-in Customer'}",
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),
          const Text("Select Payment Method / पेमेंट पद्धत", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),

          // Payment Mode Selector Cards
          _buildPaymentCard(
            title: "Cash / रोख",
            subtitle: "Cash in hand collection",
            icon: Icons.money,
            mode: "CASH",
            color: AppColors.primaryGreen,
          ),
          const SizedBox(height: 8),
          _buildPaymentCard(
            title: "Instant UPI QR Code",
            subtitle: "Customer scans GPay, PhonePe, Paytm",
            icon: Icons.qr_code_2,
            mode: "UPI",
            color: AppColors.secondaryAmber,
          ),
          const SizedBox(height: 8),
          _buildPaymentCard(
            title: "Khata (Udhaar / उधार)",
            subtitle: "Add to customer's credit ledger",
            icon: Icons.book,
            mode: "CREDIT",
            color: AppColors.error,
          ),

          const SizedBox(height: 20),

          // Bill Summary Breakdown
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _summaryRow("Subtotal (${billing.totalItemCount} items)", CurrencyFormatter.format(billing.subtotal)),
                  const SizedBox(height: 8),
                  _summaryRow("GST Tax", CurrencyFormatter.format(billing.totalGstAmount)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Discount (₹)"),
                      SizedBox(
                        width: 90,
                        height: 36,
                        child: TextField(
                          controller: _discountController,
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.right,
                          decoration: const InputDecoration(
                            hintText: "0.00",
                            contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          ),
                          onChanged: (val) {
                            final d = double.tryParse(val) ?? 0.0;
                            billing.setBillDiscount(d);
                          },
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  _summaryRow("Final Payable", CurrencyFormatter.format(billing.grandTotal), isBold: true, color: AppColors.primaryGreen),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required String mode,
    required Color color,
  }) {
    final isSelected = _selectedMode == mode;
    return Card(
      elevation: isSelected ? 2 : 0.5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: isSelected ? color : Colors.transparent, width: 2),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _selectedMode = mode),
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              if (isSelected) Icon(Icons.check_circle, color: color, size: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool isBold = false, Color? color}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 15 : 13)),
        Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.w900 : FontWeight.bold, fontSize: isBold ? 16 : 13, color: color)),
      ],
    );
  }

  RoundedRectangleBorder RoundedCornerShape(double radius) => RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius));
}
