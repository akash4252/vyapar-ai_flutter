import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/voice/voice_parser_engine.dart';
import '../../providers/billing_provider.dart';
import '../../providers/product_provider.dart';
import '../../providers/khata_provider.dart';
import '../../providers/report_provider.dart';
import '../../providers/settings_provider.dart';
import '../common/stat_card.dart';
import '../common/voice_confirmation_sheet.dart';
import '../navigation/app_routes.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void _triggerVoiceBillingModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return VoiceConfirmationSheet(
          spokenText: "मैगी दो आणि साखर एक किलो",
          parsedResult: VoiceParserEngine.parse("Maggi 2 and sugar 1 kg"),
          onConfirm: () {
            final billing = context.read<BillingProvider>();
            final products = context.read<ProductProvider>().products;

            final maggi = products.firstWhere((p) => p.name.contains("Maggi"), orElse: () => products.first);
            final sugar = products.firstWhere((p) => p.name.contains("Sugar"), orElse: () => products.first);

            billing.addToCart(maggi, quantity: 2);
            billing.addToCart(sugar, quantity: 1);

            Navigator.pop(ctx);
            Navigator.pushNamed(context, AppRoutes.fastBilling);
          },
          onCancel: () => Navigator.pop(ctx),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final reports = context.watch<ReportProvider>();
    final khata = context.watch<KhataProvider>();
    final products = context.watch<ProductProvider>();

    final biz = settings.businessInfo;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              biz?.name ?? "Shree Ganesh General Store",
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
            Text(
              biz?.address ?? "Shop No. 4, MG Road, Pune",
              style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.85)),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.psychology),
            tooltip: "AI Assistant",
            onPressed: () => Navigator.pushNamed(context, AppRoutes.aiAssistant),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _triggerVoiceBillingModal(context),
        backgroundColor: AppColors.secondaryAmber,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.mic),
        label: const Text("Voice Bill / बोलून बिल", style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await reports.loadDashboardMetrics();
          await khata.loadKhata();
          await products.loadProducts();
        },
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            // Voice Billing Hero Banner
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primaryGreen, AppColors.primaryLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryGreen.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.mic, color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "AI Voice Billing",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        Text(
                          "\"Sugar 2kg 80 rs, Maggi 2\" किंवा \"मॅगी दोन\"",
                          style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppColors.primaryGreen,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: () => _triggerVoiceBillingModal(context),
                    child: const Text("SPEAK", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Metrics Grid
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: "Today's Sales",
                    value: CurrencyFormatter.format(reports.todaySales),
                    subtitle: "${reports.todayBillCount} bills generated",
                    icon: Icons.trending_up,
                    iconColor: AppColors.primaryGreen,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: StatCard(
                    title: "Est. Net Profit",
                    value: CurrencyFormatter.format(reports.todayNetProfit),
                    subtitle: "Margin after expenses",
                    icon: Icons.savings,
                    iconColor: AppColors.success,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: "Pending Udhaar",
                    value: CurrencyFormatter.format(khata.totalOutstanding),
                    subtitle: "${khata.customers.where((c) => c.currentCreditBalance > 0).length} customers",
                    icon: Icons.book,
                    iconColor: AppColors.error,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: StatCard(
                    title: "Low Stock Items",
                    value: "${products.lowStockProducts.length} Items",
                    subtitle: "Need replenishment",
                    icon: Icons.warning_amber,
                    iconColor: AppColors.secondaryAmber,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Quick Operations Grid
            const Text("Quick Actions", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 10),

            Row(
              children: [
                _buildActionTile(
                  icon: Icons.add_shopping_cart,
                  title: "New Bill",
                  color: AppColors.primaryGreen,
                  onTap: () => Navigator.pushNamed(context, AppRoutes.fastBilling),
                ),
                _buildActionTile(
                  icon: Icons.qr_code_scanner,
                  title: "Scan Barcode",
                  color: AppColors.tertiaryBlue,
                  onTap: () => Navigator.pushNamed(context, AppRoutes.barcodeScanner),
                ),
                _buildActionTile(
                  icon: Icons.document_scanner,
                  title: "AI Bill OCR",
                  color: AppColors.secondaryAmber,
                  onTap: () => Navigator.pushNamed(context, AppRoutes.aiBillScanner),
                ),
                _buildActionTile(
                  icon: Icons.auto_graph,
                  title: "Reports",
                  color: const Color(0xFF7C3AED),
                  onTap: () => Navigator.pushNamed(context, AppRoutes.reportsHub),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Recent Bills Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Recent Invoices", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, AppRoutes.billHistory),
                  child: const Text("View All"),
                ),
              ],
            ),

            if (reports.allInvoices.isEmpty) ...[
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text("No invoices generated yet today.", style: TextStyle(color: AppColors.textSecondary)),
                ),
              ),
            ] else ...[
              ...reports.allInvoices.take(5).map((invWithItems) {
                final inv = invWithItems.invoice;
                return Card(
                  elevation: 0.5,
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    title: Text(inv.customerName, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("${inv.invoiceNumber} • ${inv.paymentMode}"),
                    trailing: Text(
                      CurrencyFormatter.format(inv.grandTotal),
                      style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen, fontSize: 15),
                    ),
                    onTap: () => Navigator.pushNamed(context, AppRoutes.invoiceSuccess, arguments: inv.invoiceNumber),
                  ),
                );
              }),
            ],

            const SizedBox(height: 60),
          ],
        ),
      ),
    );
  }

  Widget _buildActionTile({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Card(
        elevation: 0.8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14.0, horizontal: 8.0),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: color, size: 22),
                ),
                const SizedBox(height: 8),
                Text(
                  title,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
