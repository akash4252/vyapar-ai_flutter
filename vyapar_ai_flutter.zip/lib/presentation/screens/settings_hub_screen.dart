import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/settings_provider.dart';
import '../../providers/product_provider.dart';
import '../../providers/khata_provider.dart';
import '../../providers/report_provider.dart';
import '../navigation/app_routes.dart';

class SettingsHubScreen extends StatelessWidget {
  const SettingsHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final biz = settings.businessInfo;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Settings & Store / सेटिंग्ज"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Store Info Card
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: AppColors.primaryGreen,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.store, color: AppColors.primaryGreen, size: 32),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          biz?.name ?? "Shree Ganesh General Store",
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                        ),
                        Text(
                          "GSTIN: ${biz?.gstin ?? 'Unregistered'}",
                          style: const TextStyle(fontSize: 12, color: Colors.white70),
                        ),
                        Text(
                          "UPI: ${biz?.upiId ?? 'shreeganesh@upi'}",
                          style: const TextStyle(fontSize: 12, color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),
          const Text("Hardware & Printing", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.textSecondary)),
          const SizedBox(height: 8),

          _buildTile(
            title: "Thermal Receipt Printer / प्रिंटर सेटिंग्ज",
            subtitle: "Configure 58mm / 80mm ESC/POS printer",
            icon: Icons.print,
            onTap: () => Navigator.pushNamed(context, AppRoutes.printerSettings),
          ),

          const SizedBox(height: 16),
          const Text("Data & Storage", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.textSecondary)),
          const SizedBox(height: 8),

          _buildTile(
            title: "Backup & Restore / डेटा बॅकअप",
            subtitle: "Offline SQLite database backup snapshot",
            icon: Icons.backup,
            onTap: () => Navigator.pushNamed(context, AppRoutes.backupRestore),
          ),
          const SizedBox(height: 8),
          _buildTile(
            title: "App Language / ॲप भाषा",
            subtitle: "English, मराठी, हिन्दी",
            icon: Icons.language,
            onTap: () => Navigator.pushNamed(context, AppRoutes.languageSettings),
          ),
          const SizedBox(height: 8),
          _buildTile(
            title: "Reload Demo Store / डेमो डेटा",
            subtitle: "Reset sample products & customers (Shree Ganesh)",
            icon: Icons.restore,
            color: AppColors.secondaryDark,
            onTap: () async {
              await settings.reloadDemoStore();
              await context.read<ProductProvider>().loadProducts();
              await context.read<KhataProvider>().loadKhata();
              await context.read<ReportProvider>().loadDashboardMetrics();

              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Demo Store reloaded successfully!"), backgroundColor: AppColors.primaryGreen),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
    Color? color,
  }) {
    final c = color ?? AppColors.primaryGreen;
    return Card(
      elevation: 0.8,
      margin: const EdgeInsets.symmetric(vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: c.withOpacity(0.12), shape: BoxShape.circle),
          child: Icon(icon, color: c, size: 22),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
      ),
    );
  }
}
