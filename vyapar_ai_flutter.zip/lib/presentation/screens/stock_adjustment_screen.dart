import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/product.dart';
import '../../providers/product_provider.dart';
import '../common/custom_buttons.dart';

class StockAdjustmentScreen extends StatefulWidget {
  const StockAdjustmentScreen({super.key});

  @override
  State<StockAdjustmentScreen> createState() => _StockAdjustmentScreenState();
}

class _StockAdjustmentScreenState extends State<StockAdjustmentScreen> {
  Product? _selectedProduct;
  final TextEditingController _newStockController = TextEditingController();
  String _reason = "PHYSICAL_COUNT";

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Stock Adjustment / साठा दुरुस्ती"),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, -4))]),
        child: SafeArea(
          child: VyaparPrimaryButton(
            text: "SAVE STOCK ADJUSTMENT / साठा अपडेट करा",
            onClick: _selectedProduct == null
                ? null
                : () async {
                    final newStock = double.tryParse(_newStockController.text);
                    if (newStock != null) {
                      await productProvider.updateStock(_selectedProduct!.id!, newStock);
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Stock updated successfully!"), backgroundColor: AppColors.primaryGreen),
                        );
                        Navigator.pop(context);
                      }
                    }
                  },
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<Product>(
            value: _selectedProduct,
            decoration: const InputDecoration(labelText: "Select Product / वस्तू निवडा"),
            items: productProvider.products.map((p) {
              return DropdownMenuItem(value: p, child: Text("${p.name} (${p.currentStock} ${p.unit})"));
            }).toList(),
            onChanged: (p) {
              setState(() {
                _selectedProduct = p;
                _newStockController.text = p?.currentStock.toString() ?? "";
              });
            },
          ),
          const SizedBox(height: 16),
          if (_selectedProduct != null) ...[
            Text("Current Stock: ${_selectedProduct!.currentStock} ${_selectedProduct!.unit}", style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: _newStockController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Correct Physical Stock / खरी संख्या (${_selectedProduct!.unit})",
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _reason,
              decoration: const InputDecoration(labelText: "Adjustment Reason / कारण"),
              items: const [
                DropdownMenuItem(value: "PHYSICAL_COUNT", child: Text("Physical Count Audit")),
                DropdownMenuItem(value: "DAMAGED", child: Text("Damaged Goods / खराब माल")),
                DropdownMenuItem(value: "EXPIRED", child: Text("Expired / मुदत संपलेला")),
                DropdownMenuItem(value: "THEFT", child: Text("Missing / चोरी")),
              ],
              onChanged: (val) => setState(() => _reason = val!),
            ),
          ],
        ],
      ),
    );
  }
}
