class AppRoutes {
  static const String splash = '/';
  static const String dashboard = '/dashboard';
  static const String fastBilling = '/fast-billing';
  static const String barcodeScanner = '/barcode-scanner';
  static const String paymentCheckout = '/payment-checkout';
  static const String invoiceSuccess = '/invoice-success';
  static const String billHistory = '/bill-history';

  static const String productList = '/products';
  static const String addEditProduct = '/add-edit-product';
  static const String inventoryDashboard = '/inventory';
  static const String stockAdjustment = '/stock-adjustment';
  static const String lowStock = '/low-stock';

  static const String digitalKhata = '/khata';
  static const String customerProfile = '/customer-profile';
  static const String addKhataEntry = '/add-khata-entry';
  static const String customerLoyalty = '/customer-loyalty';

  static const String suppliers = '/suppliers';
  static const String newPurchase = '/new-purchase';
  static const String smartPo = '/smart-po';
  static const String aiBillScanner = '/ai-bill-scanner';

  static const String reportsHub = '/reports';
  static const String salesReport = '/sales-report';
  static const String profitReport = '/profit-report';
  static const String gstReport = '/gst-report';
  static const String expenseManager = '/expenses';

  static const String aiAssistant = '/ai-assistant';
  static const String settingsHub = '/settings';
  static const String printerSettings = '/printer-settings';
  static const String backupRestore = '/backup-restore';
  static const String languageSettings = '/language-settings';
}
