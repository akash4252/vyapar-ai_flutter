import 'package:flutter_test/flutter_test.dart';
import 'package:vyapar_ai_flutter/core/voice/voice_parser_engine.dart';
import 'package:vyapar_ai_flutter/core/utils/currency_formatter.dart';
import 'package:vyapar_ai_flutter/core/utils/number_to_words.dart';

void main() {
  group('VoiceParserEngine Tests', () {
    test('Parses English product and quantity', () {
      final res = VoiceParserEngine.parse("Maggi 2");
      expect(res, isA<BillingVoiceCommand>());
      final cmd = res as BillingVoiceCommand;
      expect(cmd.items.length, 1);
      expect(cmd.items[0].productName, "Maggi");
      expect(cmd.items[0].quantity, 2.0);
    });

    test('Parses product quantity unit and price', () {
      final res = VoiceParserEngine.parse("Sugar 2kg 80 rupees");
      expect(res, isA<BillingVoiceCommand>());
      final cmd = res as BillingVoiceCommand;
      expect(cmd.items[0].productName, "Sugar");
      expect(cmd.items[0].quantity, 2.0);
      expect(cmd.items[0].unit, "kg");
      expect(cmd.items[0].price, 80.0);
    });

    test('Parses multi-item clause', () {
      final res = VoiceParserEngine.parse("Maggi 2 and sugar 1 kilo");
      expect(res, isA<BillingVoiceCommand>());
      final cmd = res as BillingVoiceCommand;
      expect(cmd.items.length, 2);
    });

    test('Parses Hindi and Marathi numeral words', () {
      final resHindi = VoiceParserEngine.parse("मैगी दो");
      expect(resHindi, isA<BillingVoiceCommand>());
      expect((resHindi as BillingVoiceCommand).items[0].quantity, 2.0);

      final resMarathi = VoiceParserEngine.parse("मॅगी दोन");
      expect(resMarathi, isA<BillingVoiceCommand>());
      expect((resMarathi as BillingVoiceCommand).items[0].quantity, 2.0);
    });

    test('Parses Khata Voice Commands', () {
      final resCredit = VoiceParserEngine.parse("Rahul ko 500 udhaar");
      expect(resCredit, isA<KhataCreditVoiceCommand>());
      expect((resCredit as KhataCreditVoiceCommand).customerName, "Rahul");
      expect((resCredit as KhataCreditVoiceCommand).amount, 500.0);

      final resPayment = VoiceParserEngine.parse("Rahul ne 300 diye");
      expect(resPayment, isA<KhataPaymentVoiceCommand>());
      expect((resPayment as KhataPaymentVoiceCommand).amount, 300.0);
    });

    test('Parses Business Intelligence Queries', () {
      final resSales = VoiceParserEngine.parse("आजची विक्री किती?");
      expect(resSales, isA<BusinessQueryVoiceCommand>());
      expect((resSales as BusinessQueryVoiceCommand).queryType, BusinessQueryType.todaySales);
    });
  });

  group('Currency & Words Tests', () {
    test('Indian Number to Words', () {
      expect(IndianNumberToWords.convert(20.0), "Rupees Twenty Only");
      expect(IndianNumberToWords.convert(1250.0), "Rupees One Thousand Two Hundred Fifty Only");
    });
  });
}
